// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA.
//
// Le code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence").
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.


package etl_phones_theme11.etl_phones_informations_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJavaRow_2
	//import java.util.List;

	//the import part of tJava_1
	//import java.util.List;

	//the import part of tJava_2
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: ETL_Phones_informations Purpose: Job pour le traitement des données de phones<br>
 * Description:  <br>
 * @author ouedraogogyslain7@gmail.com
 * @version 8.8.8.20231002_2031-SNAPSHOT
 * @status 
 */
public class ETL_Phones_informations implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "ETL_Phones_informations";
	private final String projectName = "ETL_PHONES_THEME11";
	public Integer errorCode = null;
	private String currentComponent = "";
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				ETL_Phones_informations.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(ETL_Phones_informations.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tFileInputDelimited_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	






public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];
    static byte[] commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];

	
			    public String marque;

				public String getMarque () {
					return this.marque;
				}

				public Boolean marqueIsNullable(){
				    return true;
				}
				public Boolean marqueIsKey(){
				    return false;
				}
				public Integer marqueLength(){
				    return 50;
				}
				public Integer marquePrecision(){
				    return 0;
				}
				public String marqueDefault(){
				
					return null;
				
				}
				public String marqueComment(){
				
				    return "";
				
				}
				public String marquePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String marqueOriginalDbColumnName(){
				
					return "marque";
				
				}

				
			    public String modele;

				public String getModele () {
					return this.modele;
				}

				public Boolean modeleIsNullable(){
				    return true;
				}
				public Boolean modeleIsKey(){
				    return false;
				}
				public Integer modeleLength(){
				    return 50;
				}
				public Integer modelePrecision(){
				    return 0;
				}
				public String modeleDefault(){
				
					return null;
				
				}
				public String modeleComment(){
				
				    return "";
				
				}
				public String modelePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String modeleOriginalDbColumnName(){
				
					return "modele";
				
				}

				
			    public Float prix_usd;

				public Float getPrix_usd () {
					return this.prix_usd;
				}

				public Boolean prix_usdIsNullable(){
				    return true;
				}
				public Boolean prix_usdIsKey(){
				    return false;
				}
				public Integer prix_usdLength(){
				    return 6;
				}
				public Integer prix_usdPrecision(){
				    return 0;
				}
				public String prix_usdDefault(){
				
					return null;
				
				}
				public String prix_usdComment(){
				
				    return "";
				
				}
				public String prix_usdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String prix_usdOriginalDbColumnName(){
				
					return "prix_usd";
				
				}

				
			    public Integer ram_gb;

				public Integer getRam_gb () {
					return this.ram_gb;
				}

				public Boolean ram_gbIsNullable(){
				    return true;
				}
				public Boolean ram_gbIsKey(){
				    return false;
				}
				public Integer ram_gbLength(){
				    return 10;
				}
				public Integer ram_gbPrecision(){
				    return 0;
				}
				public String ram_gbDefault(){
				
					return null;
				
				}
				public String ram_gbComment(){
				
				    return "";
				
				}
				public String ram_gbPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ram_gbOriginalDbColumnName(){
				
					return "ram_gb";
				
				}

				
			    public Integer storage_gb;

				public Integer getStorage_gb () {
					return this.storage_gb;
				}

				public Boolean storage_gbIsNullable(){
				    return true;
				}
				public Boolean storage_gbIsKey(){
				    return false;
				}
				public Integer storage_gbLength(){
				    return 10;
				}
				public Integer storage_gbPrecision(){
				    return 0;
				}
				public String storage_gbDefault(){
				
					return null;
				
				}
				public String storage_gbComment(){
				
				    return "";
				
				}
				public String storage_gbPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String storage_gbOriginalDbColumnName(){
				
					return "storage_gb";
				
				}

				
			    public String support5g;

				public String getSupport5g () {
					return this.support5g;
				}

				public Boolean support5gIsNullable(){
				    return true;
				}
				public Boolean support5gIsKey(){
				    return false;
				}
				public Integer support5gLength(){
				    return 3;
				}
				public Integer support5gPrecision(){
				    return 0;
				}
				public String support5gDefault(){
				
					return null;
				
				}
				public String support5gComment(){
				
				    return "";
				
				}
				public String support5gPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String support5gOriginalDbColumnName(){
				
					return "support5g";
				
				}

				
			    public String os;

				public String getOs () {
					return this.os;
				}

				public Boolean osIsNullable(){
				    return true;
				}
				public Boolean osIsKey(){
				    return false;
				}
				public Integer osLength(){
				    return 7;
				}
				public Integer osPrecision(){
				    return 0;
				}
				public String osDefault(){
				
					return null;
				
				}
				public String osComment(){
				
				    return "";
				
				}
				public String osPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String osOriginalDbColumnName(){
				
					return "os";
				
				}

				
			    public String date_sortie;

				public String getDate_sortie () {
					return this.date_sortie;
				}

				public Boolean date_sortieIsNullable(){
				    return true;
				}
				public Boolean date_sortieIsKey(){
				    return false;
				}
				public Integer date_sortieLength(){
				    return 20;
				}
				public Integer date_sortiePrecision(){
				    return 0;
				}
				public String date_sortieDefault(){
				
					return null;
				
				}
				public String date_sortieComment(){
				
				    return "";
				
				}
				public String date_sortiePattern(){
				
					return "";
				
				}
				public String date_sortieOriginalDbColumnName(){
				
					return "date_sortie";
				
				}

				
			    public Float prix_cfa;

				public Float getPrix_cfa () {
					return this.prix_cfa;
				}

				public Boolean prix_cfaIsNullable(){
				    return true;
				}
				public Boolean prix_cfaIsKey(){
				    return false;
				}
				public Integer prix_cfaLength(){
				    return 20;
				}
				public Integer prix_cfaPrecision(){
				    return null;
				}
				public String prix_cfaDefault(){
				
					return null;
				
				}
				public String prix_cfaComment(){
				
				    return "";
				
				}
				public String prix_cfaPattern(){
				
					return "";
				
				}
				public String prix_cfaOriginalDbColumnName(){
				
					return "prix_cfa";
				
				}

				
			    public String vendeur;

				public String getVendeur () {
					return this.vendeur;
				}

				public Boolean vendeurIsNullable(){
				    return true;
				}
				public Boolean vendeurIsKey(){
				    return false;
				}
				public Integer vendeurLength(){
				    return 50;
				}
				public Integer vendeurPrecision(){
				    return 0;
				}
				public String vendeurDefault(){
				
					return null;
				
				}
				public String vendeurComment(){
				
				    return "";
				
				}
				public String vendeurPattern(){
				
					return "";
				
				}
				public String vendeurOriginalDbColumnName(){
				
					return "vendeur";
				
				}

				
			    public String Pays;

				public String getPays () {
					return this.Pays;
				}

				public Boolean PaysIsNullable(){
				    return true;
				}
				public Boolean PaysIsKey(){
				    return false;
				}
				public Integer PaysLength(){
				    return 50;
				}
				public Integer PaysPrecision(){
				    return 0;
				}
				public String PaysDefault(){
				
					return null;
				
				}
				public String PaysComment(){
				
				    return "";
				
				}
				public String PaysPattern(){
				
					return "";
				
				}
				public String PaysOriginalDbColumnName(){
				
					return "Pays";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.marque = readString(dis);
					
					this.modele = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_usd = null;
           				} else {
           			    	this.prix_usd = dis.readFloat();
           				}
					
						this.ram_gb = readInteger(dis);
					
						this.storage_gb = readInteger(dis);
					
					this.support5g = readString(dis);
					
					this.os = readString(dis);
					
					this.date_sortie = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_cfa = null;
           				} else {
           			    	this.prix_cfa = dis.readFloat();
           				}
					
					this.vendeur = readString(dis);
					
					this.Pays = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.marque = readString(dis);
					
					this.modele = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_usd = null;
           				} else {
           			    	this.prix_usd = dis.readFloat();
           				}
					
						this.ram_gb = readInteger(dis);
					
						this.storage_gb = readInteger(dis);
					
					this.support5g = readString(dis);
					
					this.os = readString(dis);
					
					this.date_sortie = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_cfa = null;
           				} else {
           			    	this.prix_cfa = dis.readFloat();
           				}
					
					this.vendeur = readString(dis);
					
					this.Pays = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.marque,dos);
					
					// String
				
						writeString(this.modele,dos);
					
					// Float
				
						if(this.prix_usd == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_usd);
		            	}
					
					// Integer
				
						writeInteger(this.ram_gb,dos);
					
					// Integer
				
						writeInteger(this.storage_gb,dos);
					
					// String
				
						writeString(this.support5g,dos);
					
					// String
				
						writeString(this.os,dos);
					
					// String
				
						writeString(this.date_sortie,dos);
					
					// Float
				
						if(this.prix_cfa == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_cfa);
		            	}
					
					// String
				
						writeString(this.vendeur,dos);
					
					// String
				
						writeString(this.Pays,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.marque,dos);
					
					// String
				
						writeString(this.modele,dos);
					
					// Float
				
						if(this.prix_usd == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_usd);
		            	}
					
					// Integer
				
						writeInteger(this.ram_gb,dos);
					
					// Integer
				
						writeInteger(this.storage_gb,dos);
					
					// String
				
						writeString(this.support5g,dos);
					
					// String
				
						writeString(this.os,dos);
					
					// String
				
						writeString(this.date_sortie,dos);
					
					// Float
				
						if(this.prix_cfa == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_cfa);
		            	}
					
					// String
				
						writeString(this.vendeur,dos);
					
					// String
				
						writeString(this.Pays,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("marque="+marque);
		sb.append(",modele="+modele);
		sb.append(",prix_usd="+String.valueOf(prix_usd));
		sb.append(",ram_gb="+String.valueOf(ram_gb));
		sb.append(",storage_gb="+String.valueOf(storage_gb));
		sb.append(",support5g="+support5g);
		sb.append(",os="+os);
		sb.append(",date_sortie="+date_sortie);
		sb.append(",prix_cfa="+String.valueOf(prix_cfa));
		sb.append(",vendeur="+vendeur);
		sb.append(",Pays="+Pays);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];
    static byte[] commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];

	
			    public String marque;

				public String getMarque () {
					return this.marque;
				}

				public Boolean marqueIsNullable(){
				    return true;
				}
				public Boolean marqueIsKey(){
				    return false;
				}
				public Integer marqueLength(){
				    return 50;
				}
				public Integer marquePrecision(){
				    return 0;
				}
				public String marqueDefault(){
				
					return null;
				
				}
				public String marqueComment(){
				
				    return "";
				
				}
				public String marquePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String marqueOriginalDbColumnName(){
				
					return "marque";
				
				}

				
			    public String modele;

				public String getModele () {
					return this.modele;
				}

				public Boolean modeleIsNullable(){
				    return true;
				}
				public Boolean modeleIsKey(){
				    return false;
				}
				public Integer modeleLength(){
				    return 50;
				}
				public Integer modelePrecision(){
				    return 0;
				}
				public String modeleDefault(){
				
					return null;
				
				}
				public String modeleComment(){
				
				    return "";
				
				}
				public String modelePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String modeleOriginalDbColumnName(){
				
					return "modele";
				
				}

				
			    public Float prix_usd;

				public Float getPrix_usd () {
					return this.prix_usd;
				}

				public Boolean prix_usdIsNullable(){
				    return true;
				}
				public Boolean prix_usdIsKey(){
				    return false;
				}
				public Integer prix_usdLength(){
				    return 6;
				}
				public Integer prix_usdPrecision(){
				    return 0;
				}
				public String prix_usdDefault(){
				
					return null;
				
				}
				public String prix_usdComment(){
				
				    return "";
				
				}
				public String prix_usdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String prix_usdOriginalDbColumnName(){
				
					return "prix_usd";
				
				}

				
			    public Integer ram_gb;

				public Integer getRam_gb () {
					return this.ram_gb;
				}

				public Boolean ram_gbIsNullable(){
				    return true;
				}
				public Boolean ram_gbIsKey(){
				    return false;
				}
				public Integer ram_gbLength(){
				    return 10;
				}
				public Integer ram_gbPrecision(){
				    return 0;
				}
				public String ram_gbDefault(){
				
					return null;
				
				}
				public String ram_gbComment(){
				
				    return "";
				
				}
				public String ram_gbPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ram_gbOriginalDbColumnName(){
				
					return "ram_gb";
				
				}

				
			    public Integer storage_gb;

				public Integer getStorage_gb () {
					return this.storage_gb;
				}

				public Boolean storage_gbIsNullable(){
				    return true;
				}
				public Boolean storage_gbIsKey(){
				    return false;
				}
				public Integer storage_gbLength(){
				    return 10;
				}
				public Integer storage_gbPrecision(){
				    return 0;
				}
				public String storage_gbDefault(){
				
					return null;
				
				}
				public String storage_gbComment(){
				
				    return "";
				
				}
				public String storage_gbPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String storage_gbOriginalDbColumnName(){
				
					return "storage_gb";
				
				}

				
			    public String support5g;

				public String getSupport5g () {
					return this.support5g;
				}

				public Boolean support5gIsNullable(){
				    return true;
				}
				public Boolean support5gIsKey(){
				    return false;
				}
				public Integer support5gLength(){
				    return 3;
				}
				public Integer support5gPrecision(){
				    return 0;
				}
				public String support5gDefault(){
				
					return null;
				
				}
				public String support5gComment(){
				
				    return "";
				
				}
				public String support5gPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String support5gOriginalDbColumnName(){
				
					return "support5g";
				
				}

				
			    public String os;

				public String getOs () {
					return this.os;
				}

				public Boolean osIsNullable(){
				    return true;
				}
				public Boolean osIsKey(){
				    return false;
				}
				public Integer osLength(){
				    return 7;
				}
				public Integer osPrecision(){
				    return 0;
				}
				public String osDefault(){
				
					return null;
				
				}
				public String osComment(){
				
				    return "";
				
				}
				public String osPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String osOriginalDbColumnName(){
				
					return "os";
				
				}

				
			    public String date_sortie;

				public String getDate_sortie () {
					return this.date_sortie;
				}

				public Boolean date_sortieIsNullable(){
				    return true;
				}
				public Boolean date_sortieIsKey(){
				    return false;
				}
				public Integer date_sortieLength(){
				    return 20;
				}
				public Integer date_sortiePrecision(){
				    return 0;
				}
				public String date_sortieDefault(){
				
					return null;
				
				}
				public String date_sortieComment(){
				
				    return "";
				
				}
				public String date_sortiePattern(){
				
					return "";
				
				}
				public String date_sortieOriginalDbColumnName(){
				
					return "date_sortie";
				
				}

				
			    public Float prix_cfa;

				public Float getPrix_cfa () {
					return this.prix_cfa;
				}

				public Boolean prix_cfaIsNullable(){
				    return true;
				}
				public Boolean prix_cfaIsKey(){
				    return false;
				}
				public Integer prix_cfaLength(){
				    return 20;
				}
				public Integer prix_cfaPrecision(){
				    return null;
				}
				public String prix_cfaDefault(){
				
					return null;
				
				}
				public String prix_cfaComment(){
				
				    return "";
				
				}
				public String prix_cfaPattern(){
				
					return "";
				
				}
				public String prix_cfaOriginalDbColumnName(){
				
					return "prix_cfa";
				
				}

				
			    public String vendeur;

				public String getVendeur () {
					return this.vendeur;
				}

				public Boolean vendeurIsNullable(){
				    return true;
				}
				public Boolean vendeurIsKey(){
				    return false;
				}
				public Integer vendeurLength(){
				    return 50;
				}
				public Integer vendeurPrecision(){
				    return 0;
				}
				public String vendeurDefault(){
				
					return null;
				
				}
				public String vendeurComment(){
				
				    return "";
				
				}
				public String vendeurPattern(){
				
					return "";
				
				}
				public String vendeurOriginalDbColumnName(){
				
					return "vendeur";
				
				}

				
			    public String Pays;

				public String getPays () {
					return this.Pays;
				}

				public Boolean PaysIsNullable(){
				    return true;
				}
				public Boolean PaysIsKey(){
				    return false;
				}
				public Integer PaysLength(){
				    return 50;
				}
				public Integer PaysPrecision(){
				    return 0;
				}
				public String PaysDefault(){
				
					return null;
				
				}
				public String PaysComment(){
				
				    return "";
				
				}
				public String PaysPattern(){
				
					return "";
				
				}
				public String PaysOriginalDbColumnName(){
				
					return "Pays";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.marque = readString(dis);
					
					this.modele = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_usd = null;
           				} else {
           			    	this.prix_usd = dis.readFloat();
           				}
					
						this.ram_gb = readInteger(dis);
					
						this.storage_gb = readInteger(dis);
					
					this.support5g = readString(dis);
					
					this.os = readString(dis);
					
					this.date_sortie = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_cfa = null;
           				} else {
           			    	this.prix_cfa = dis.readFloat();
           				}
					
					this.vendeur = readString(dis);
					
					this.Pays = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.marque = readString(dis);
					
					this.modele = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_usd = null;
           				} else {
           			    	this.prix_usd = dis.readFloat();
           				}
					
						this.ram_gb = readInteger(dis);
					
						this.storage_gb = readInteger(dis);
					
					this.support5g = readString(dis);
					
					this.os = readString(dis);
					
					this.date_sortie = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_cfa = null;
           				} else {
           			    	this.prix_cfa = dis.readFloat();
           				}
					
					this.vendeur = readString(dis);
					
					this.Pays = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.marque,dos);
					
					// String
				
						writeString(this.modele,dos);
					
					// Float
				
						if(this.prix_usd == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_usd);
		            	}
					
					// Integer
				
						writeInteger(this.ram_gb,dos);
					
					// Integer
				
						writeInteger(this.storage_gb,dos);
					
					// String
				
						writeString(this.support5g,dos);
					
					// String
				
						writeString(this.os,dos);
					
					// String
				
						writeString(this.date_sortie,dos);
					
					// Float
				
						if(this.prix_cfa == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_cfa);
		            	}
					
					// String
				
						writeString(this.vendeur,dos);
					
					// String
				
						writeString(this.Pays,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.marque,dos);
					
					// String
				
						writeString(this.modele,dos);
					
					// Float
				
						if(this.prix_usd == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_usd);
		            	}
					
					// Integer
				
						writeInteger(this.ram_gb,dos);
					
					// Integer
				
						writeInteger(this.storage_gb,dos);
					
					// String
				
						writeString(this.support5g,dos);
					
					// String
				
						writeString(this.os,dos);
					
					// String
				
						writeString(this.date_sortie,dos);
					
					// Float
				
						if(this.prix_cfa == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_cfa);
		            	}
					
					// String
				
						writeString(this.vendeur,dos);
					
					// String
				
						writeString(this.Pays,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("marque="+marque);
		sb.append(",modele="+modele);
		sb.append(",prix_usd="+String.valueOf(prix_usd));
		sb.append(",ram_gb="+String.valueOf(ram_gb));
		sb.append(",storage_gb="+String.valueOf(storage_gb));
		sb.append(",support5g="+support5g);
		sb.append(",os="+os);
		sb.append(",date_sortie="+date_sortie);
		sb.append(",prix_cfa="+String.valueOf(prix_cfa));
		sb.append(",vendeur="+vendeur);
		sb.append(",Pays="+Pays);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class csv_mysqlStruct implements routines.system.IPersistableRow<csv_mysqlStruct> {
    final static byte[] commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];
    static byte[] commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];

	
			    public String marque;

				public String getMarque () {
					return this.marque;
				}

				public Boolean marqueIsNullable(){
				    return true;
				}
				public Boolean marqueIsKey(){
				    return false;
				}
				public Integer marqueLength(){
				    return 50;
				}
				public Integer marquePrecision(){
				    return 0;
				}
				public String marqueDefault(){
				
					return null;
				
				}
				public String marqueComment(){
				
				    return "";
				
				}
				public String marquePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String marqueOriginalDbColumnName(){
				
					return "marque";
				
				}

				
			    public String modele;

				public String getModele () {
					return this.modele;
				}

				public Boolean modeleIsNullable(){
				    return true;
				}
				public Boolean modeleIsKey(){
				    return false;
				}
				public Integer modeleLength(){
				    return 50;
				}
				public Integer modelePrecision(){
				    return 0;
				}
				public String modeleDefault(){
				
					return null;
				
				}
				public String modeleComment(){
				
				    return "";
				
				}
				public String modelePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String modeleOriginalDbColumnName(){
				
					return "modele";
				
				}

				
			    public Float prix_usd;

				public Float getPrix_usd () {
					return this.prix_usd;
				}

				public Boolean prix_usdIsNullable(){
				    return true;
				}
				public Boolean prix_usdIsKey(){
				    return false;
				}
				public Integer prix_usdLength(){
				    return 6;
				}
				public Integer prix_usdPrecision(){
				    return 0;
				}
				public String prix_usdDefault(){
				
					return null;
				
				}
				public String prix_usdComment(){
				
				    return "";
				
				}
				public String prix_usdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String prix_usdOriginalDbColumnName(){
				
					return "prix_usd";
				
				}

				
			    public Integer ram_gb;

				public Integer getRam_gb () {
					return this.ram_gb;
				}

				public Boolean ram_gbIsNullable(){
				    return true;
				}
				public Boolean ram_gbIsKey(){
				    return false;
				}
				public Integer ram_gbLength(){
				    return 10;
				}
				public Integer ram_gbPrecision(){
				    return 0;
				}
				public String ram_gbDefault(){
				
					return null;
				
				}
				public String ram_gbComment(){
				
				    return "";
				
				}
				public String ram_gbPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ram_gbOriginalDbColumnName(){
				
					return "ram_gb";
				
				}

				
			    public Integer storage_gb;

				public Integer getStorage_gb () {
					return this.storage_gb;
				}

				public Boolean storage_gbIsNullable(){
				    return true;
				}
				public Boolean storage_gbIsKey(){
				    return false;
				}
				public Integer storage_gbLength(){
				    return 10;
				}
				public Integer storage_gbPrecision(){
				    return 0;
				}
				public String storage_gbDefault(){
				
					return null;
				
				}
				public String storage_gbComment(){
				
				    return "";
				
				}
				public String storage_gbPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String storage_gbOriginalDbColumnName(){
				
					return "storage_gb";
				
				}

				
			    public String support5g;

				public String getSupport5g () {
					return this.support5g;
				}

				public Boolean support5gIsNullable(){
				    return true;
				}
				public Boolean support5gIsKey(){
				    return false;
				}
				public Integer support5gLength(){
				    return 3;
				}
				public Integer support5gPrecision(){
				    return 0;
				}
				public String support5gDefault(){
				
					return null;
				
				}
				public String support5gComment(){
				
				    return "";
				
				}
				public String support5gPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String support5gOriginalDbColumnName(){
				
					return "support5g";
				
				}

				
			    public String os;

				public String getOs () {
					return this.os;
				}

				public Boolean osIsNullable(){
				    return true;
				}
				public Boolean osIsKey(){
				    return false;
				}
				public Integer osLength(){
				    return 7;
				}
				public Integer osPrecision(){
				    return 0;
				}
				public String osDefault(){
				
					return null;
				
				}
				public String osComment(){
				
				    return "";
				
				}
				public String osPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String osOriginalDbColumnName(){
				
					return "os";
				
				}

				
			    public String date_sortie;

				public String getDate_sortie () {
					return this.date_sortie;
				}

				public Boolean date_sortieIsNullable(){
				    return true;
				}
				public Boolean date_sortieIsKey(){
				    return false;
				}
				public Integer date_sortieLength(){
				    return 20;
				}
				public Integer date_sortiePrecision(){
				    return 0;
				}
				public String date_sortieDefault(){
				
					return null;
				
				}
				public String date_sortieComment(){
				
				    return "";
				
				}
				public String date_sortiePattern(){
				
					return "";
				
				}
				public String date_sortieOriginalDbColumnName(){
				
					return "date_sortie";
				
				}

				
			    public Float prix_cfa;

				public Float getPrix_cfa () {
					return this.prix_cfa;
				}

				public Boolean prix_cfaIsNullable(){
				    return true;
				}
				public Boolean prix_cfaIsKey(){
				    return false;
				}
				public Integer prix_cfaLength(){
				    return 20;
				}
				public Integer prix_cfaPrecision(){
				    return null;
				}
				public String prix_cfaDefault(){
				
					return null;
				
				}
				public String prix_cfaComment(){
				
				    return "";
				
				}
				public String prix_cfaPattern(){
				
					return "";
				
				}
				public String prix_cfaOriginalDbColumnName(){
				
					return "prix_cfa";
				
				}

				
			    public String vendeur;

				public String getVendeur () {
					return this.vendeur;
				}

				public Boolean vendeurIsNullable(){
				    return true;
				}
				public Boolean vendeurIsKey(){
				    return false;
				}
				public Integer vendeurLength(){
				    return 50;
				}
				public Integer vendeurPrecision(){
				    return 0;
				}
				public String vendeurDefault(){
				
					return null;
				
				}
				public String vendeurComment(){
				
				    return "";
				
				}
				public String vendeurPattern(){
				
					return "";
				
				}
				public String vendeurOriginalDbColumnName(){
				
					return "vendeur";
				
				}

				
			    public String Pays;

				public String getPays () {
					return this.Pays;
				}

				public Boolean PaysIsNullable(){
				    return true;
				}
				public Boolean PaysIsKey(){
				    return false;
				}
				public Integer PaysLength(){
				    return 50;
				}
				public Integer PaysPrecision(){
				    return 0;
				}
				public String PaysDefault(){
				
					return null;
				
				}
				public String PaysComment(){
				
				    return "";
				
				}
				public String PaysPattern(){
				
					return "";
				
				}
				public String PaysOriginalDbColumnName(){
				
					return "Pays";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.marque = readString(dis);
					
					this.modele = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_usd = null;
           				} else {
           			    	this.prix_usd = dis.readFloat();
           				}
					
						this.ram_gb = readInteger(dis);
					
						this.storage_gb = readInteger(dis);
					
					this.support5g = readString(dis);
					
					this.os = readString(dis);
					
					this.date_sortie = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_cfa = null;
           				} else {
           			    	this.prix_cfa = dis.readFloat();
           				}
					
					this.vendeur = readString(dis);
					
					this.Pays = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.marque = readString(dis);
					
					this.modele = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_usd = null;
           				} else {
           			    	this.prix_usd = dis.readFloat();
           				}
					
						this.ram_gb = readInteger(dis);
					
						this.storage_gb = readInteger(dis);
					
					this.support5g = readString(dis);
					
					this.os = readString(dis);
					
					this.date_sortie = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_cfa = null;
           				} else {
           			    	this.prix_cfa = dis.readFloat();
           				}
					
					this.vendeur = readString(dis);
					
					this.Pays = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.marque,dos);
					
					// String
				
						writeString(this.modele,dos);
					
					// Float
				
						if(this.prix_usd == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_usd);
		            	}
					
					// Integer
				
						writeInteger(this.ram_gb,dos);
					
					// Integer
				
						writeInteger(this.storage_gb,dos);
					
					// String
				
						writeString(this.support5g,dos);
					
					// String
				
						writeString(this.os,dos);
					
					// String
				
						writeString(this.date_sortie,dos);
					
					// Float
				
						if(this.prix_cfa == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_cfa);
		            	}
					
					// String
				
						writeString(this.vendeur,dos);
					
					// String
				
						writeString(this.Pays,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.marque,dos);
					
					// String
				
						writeString(this.modele,dos);
					
					// Float
				
						if(this.prix_usd == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_usd);
		            	}
					
					// Integer
				
						writeInteger(this.ram_gb,dos);
					
					// Integer
				
						writeInteger(this.storage_gb,dos);
					
					// String
				
						writeString(this.support5g,dos);
					
					// String
				
						writeString(this.os,dos);
					
					// String
				
						writeString(this.date_sortie,dos);
					
					// Float
				
						if(this.prix_cfa == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_cfa);
		            	}
					
					// String
				
						writeString(this.vendeur,dos);
					
					// String
				
						writeString(this.Pays,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("marque="+marque);
		sb.append(",modele="+modele);
		sb.append(",prix_usd="+String.valueOf(prix_usd));
		sb.append(",ram_gb="+String.valueOf(ram_gb));
		sb.append(",storage_gb="+String.valueOf(storage_gb));
		sb.append(",support5g="+support5g);
		sb.append(",os="+os);
		sb.append(",date_sortie="+date_sortie);
		sb.append(",prix_cfa="+String.valueOf(prix_cfa));
		sb.append(",vendeur="+vendeur);
		sb.append(",Pays="+Pays);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(csv_mysqlStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class Final_dataStruct implements routines.system.IPersistableRow<Final_dataStruct> {
    final static byte[] commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];
    static byte[] commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];

	
			    public String marque;

				public String getMarque () {
					return this.marque;
				}

				public Boolean marqueIsNullable(){
				    return true;
				}
				public Boolean marqueIsKey(){
				    return false;
				}
				public Integer marqueLength(){
				    return 50;
				}
				public Integer marquePrecision(){
				    return 0;
				}
				public String marqueDefault(){
				
					return null;
				
				}
				public String marqueComment(){
				
				    return "";
				
				}
				public String marquePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String marqueOriginalDbColumnName(){
				
					return "marque";
				
				}

				
			    public String modele;

				public String getModele () {
					return this.modele;
				}

				public Boolean modeleIsNullable(){
				    return true;
				}
				public Boolean modeleIsKey(){
				    return false;
				}
				public Integer modeleLength(){
				    return 50;
				}
				public Integer modelePrecision(){
				    return 0;
				}
				public String modeleDefault(){
				
					return null;
				
				}
				public String modeleComment(){
				
				    return "";
				
				}
				public String modelePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String modeleOriginalDbColumnName(){
				
					return "modele";
				
				}

				
			    public Float prix_usd;

				public Float getPrix_usd () {
					return this.prix_usd;
				}

				public Boolean prix_usdIsNullable(){
				    return true;
				}
				public Boolean prix_usdIsKey(){
				    return false;
				}
				public Integer prix_usdLength(){
				    return 6;
				}
				public Integer prix_usdPrecision(){
				    return 0;
				}
				public String prix_usdDefault(){
				
					return null;
				
				}
				public String prix_usdComment(){
				
				    return "";
				
				}
				public String prix_usdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String prix_usdOriginalDbColumnName(){
				
					return "prix_usd";
				
				}

				
			    public Integer ram_gb;

				public Integer getRam_gb () {
					return this.ram_gb;
				}

				public Boolean ram_gbIsNullable(){
				    return true;
				}
				public Boolean ram_gbIsKey(){
				    return false;
				}
				public Integer ram_gbLength(){
				    return 10;
				}
				public Integer ram_gbPrecision(){
				    return 0;
				}
				public String ram_gbDefault(){
				
					return null;
				
				}
				public String ram_gbComment(){
				
				    return "";
				
				}
				public String ram_gbPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ram_gbOriginalDbColumnName(){
				
					return "ram_gb";
				
				}

				
			    public Integer storage_gb;

				public Integer getStorage_gb () {
					return this.storage_gb;
				}

				public Boolean storage_gbIsNullable(){
				    return true;
				}
				public Boolean storage_gbIsKey(){
				    return false;
				}
				public Integer storage_gbLength(){
				    return 10;
				}
				public Integer storage_gbPrecision(){
				    return 0;
				}
				public String storage_gbDefault(){
				
					return null;
				
				}
				public String storage_gbComment(){
				
				    return "";
				
				}
				public String storage_gbPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String storage_gbOriginalDbColumnName(){
				
					return "storage_gb";
				
				}

				
			    public String support5g;

				public String getSupport5g () {
					return this.support5g;
				}

				public Boolean support5gIsNullable(){
				    return true;
				}
				public Boolean support5gIsKey(){
				    return false;
				}
				public Integer support5gLength(){
				    return 3;
				}
				public Integer support5gPrecision(){
				    return 0;
				}
				public String support5gDefault(){
				
					return null;
				
				}
				public String support5gComment(){
				
				    return "";
				
				}
				public String support5gPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String support5gOriginalDbColumnName(){
				
					return "support5g";
				
				}

				
			    public String os;

				public String getOs () {
					return this.os;
				}

				public Boolean osIsNullable(){
				    return true;
				}
				public Boolean osIsKey(){
				    return false;
				}
				public Integer osLength(){
				    return 7;
				}
				public Integer osPrecision(){
				    return 0;
				}
				public String osDefault(){
				
					return null;
				
				}
				public String osComment(){
				
				    return "";
				
				}
				public String osPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String osOriginalDbColumnName(){
				
					return "os";
				
				}

				
			    public String date_sortie;

				public String getDate_sortie () {
					return this.date_sortie;
				}

				public Boolean date_sortieIsNullable(){
				    return true;
				}
				public Boolean date_sortieIsKey(){
				    return false;
				}
				public Integer date_sortieLength(){
				    return 20;
				}
				public Integer date_sortiePrecision(){
				    return 0;
				}
				public String date_sortieDefault(){
				
					return null;
				
				}
				public String date_sortieComment(){
				
				    return "";
				
				}
				public String date_sortiePattern(){
				
					return "";
				
				}
				public String date_sortieOriginalDbColumnName(){
				
					return "date_sortie";
				
				}

				
			    public Float prix_cfa;

				public Float getPrix_cfa () {
					return this.prix_cfa;
				}

				public Boolean prix_cfaIsNullable(){
				    return true;
				}
				public Boolean prix_cfaIsKey(){
				    return false;
				}
				public Integer prix_cfaLength(){
				    return 20;
				}
				public Integer prix_cfaPrecision(){
				    return null;
				}
				public String prix_cfaDefault(){
				
					return null;
				
				}
				public String prix_cfaComment(){
				
				    return "";
				
				}
				public String prix_cfaPattern(){
				
					return "";
				
				}
				public String prix_cfaOriginalDbColumnName(){
				
					return "prix_cfa";
				
				}

				
			    public String vendeur;

				public String getVendeur () {
					return this.vendeur;
				}

				public Boolean vendeurIsNullable(){
				    return true;
				}
				public Boolean vendeurIsKey(){
				    return false;
				}
				public Integer vendeurLength(){
				    return 50;
				}
				public Integer vendeurPrecision(){
				    return 0;
				}
				public String vendeurDefault(){
				
					return null;
				
				}
				public String vendeurComment(){
				
				    return "";
				
				}
				public String vendeurPattern(){
				
					return "";
				
				}
				public String vendeurOriginalDbColumnName(){
				
					return "vendeur";
				
				}

				
			    public String Pays;

				public String getPays () {
					return this.Pays;
				}

				public Boolean PaysIsNullable(){
				    return true;
				}
				public Boolean PaysIsKey(){
				    return false;
				}
				public Integer PaysLength(){
				    return 50;
				}
				public Integer PaysPrecision(){
				    return 0;
				}
				public String PaysDefault(){
				
					return null;
				
				}
				public String PaysComment(){
				
				    return "";
				
				}
				public String PaysPattern(){
				
					return "";
				
				}
				public String PaysOriginalDbColumnName(){
				
					return "Pays";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.marque = readString(dis);
					
					this.modele = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_usd = null;
           				} else {
           			    	this.prix_usd = dis.readFloat();
           				}
					
						this.ram_gb = readInteger(dis);
					
						this.storage_gb = readInteger(dis);
					
					this.support5g = readString(dis);
					
					this.os = readString(dis);
					
					this.date_sortie = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_cfa = null;
           				} else {
           			    	this.prix_cfa = dis.readFloat();
           				}
					
					this.vendeur = readString(dis);
					
					this.Pays = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.marque = readString(dis);
					
					this.modele = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_usd = null;
           				} else {
           			    	this.prix_usd = dis.readFloat();
           				}
					
						this.ram_gb = readInteger(dis);
					
						this.storage_gb = readInteger(dis);
					
					this.support5g = readString(dis);
					
					this.os = readString(dis);
					
					this.date_sortie = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_cfa = null;
           				} else {
           			    	this.prix_cfa = dis.readFloat();
           				}
					
					this.vendeur = readString(dis);
					
					this.Pays = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.marque,dos);
					
					// String
				
						writeString(this.modele,dos);
					
					// Float
				
						if(this.prix_usd == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_usd);
		            	}
					
					// Integer
				
						writeInteger(this.ram_gb,dos);
					
					// Integer
				
						writeInteger(this.storage_gb,dos);
					
					// String
				
						writeString(this.support5g,dos);
					
					// String
				
						writeString(this.os,dos);
					
					// String
				
						writeString(this.date_sortie,dos);
					
					// Float
				
						if(this.prix_cfa == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_cfa);
		            	}
					
					// String
				
						writeString(this.vendeur,dos);
					
					// String
				
						writeString(this.Pays,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.marque,dos);
					
					// String
				
						writeString(this.modele,dos);
					
					// Float
				
						if(this.prix_usd == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_usd);
		            	}
					
					// Integer
				
						writeInteger(this.ram_gb,dos);
					
					// Integer
				
						writeInteger(this.storage_gb,dos);
					
					// String
				
						writeString(this.support5g,dos);
					
					// String
				
						writeString(this.os,dos);
					
					// String
				
						writeString(this.date_sortie,dos);
					
					// Float
				
						if(this.prix_cfa == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_cfa);
		            	}
					
					// String
				
						writeString(this.vendeur,dos);
					
					// String
				
						writeString(this.Pays,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("marque="+marque);
		sb.append(",modele="+modele);
		sb.append(",prix_usd="+String.valueOf(prix_usd));
		sb.append(",ram_gb="+String.valueOf(ram_gb));
		sb.append(",storage_gb="+String.valueOf(storage_gb));
		sb.append(",support5g="+support5g);
		sb.append(",os="+os);
		sb.append(",date_sortie="+date_sortie);
		sb.append(",prix_cfa="+String.valueOf(prix_cfa));
		sb.append(",vendeur="+vendeur);
		sb.append(",Pays="+Pays);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(Final_dataStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];
    static byte[] commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];

	
			    public String brand;

				public String getBrand () {
					return this.brand;
				}

				public Boolean brandIsNullable(){
				    return true;
				}
				public Boolean brandIsKey(){
				    return false;
				}
				public Integer brandLength(){
				    return 50;
				}
				public Integer brandPrecision(){
				    return 0;
				}
				public String brandDefault(){
				
					return null;
				
				}
				public String brandComment(){
				
				    return "";
				
				}
				public String brandPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String brandOriginalDbColumnName(){
				
					return "brand";
				
				}

				
			    public String model;

				public String getModel () {
					return this.model;
				}

				public Boolean modelIsNullable(){
				    return true;
				}
				public Boolean modelIsKey(){
				    return false;
				}
				public Integer modelLength(){
				    return 50;
				}
				public Integer modelPrecision(){
				    return 0;
				}
				public String modelDefault(){
				
					return null;
				
				}
				public String modelComment(){
				
				    return "";
				
				}
				public String modelPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String modelOriginalDbColumnName(){
				
					return "model";
				
				}

				
			    public Float prix_usd;

				public Float getPrix_usd () {
					return this.prix_usd;
				}

				public Boolean prix_usdIsNullable(){
				    return true;
				}
				public Boolean prix_usdIsKey(){
				    return false;
				}
				public Integer prix_usdLength(){
				    return 6;
				}
				public Integer prix_usdPrecision(){
				    return 0;
				}
				public String prix_usdDefault(){
				
					return null;
				
				}
				public String prix_usdComment(){
				
				    return "";
				
				}
				public String prix_usdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String prix_usdOriginalDbColumnName(){
				
					return "prix_usd";
				
				}

				
			    public Integer ram_gb;

				public Integer getRam_gb () {
					return this.ram_gb;
				}

				public Boolean ram_gbIsNullable(){
				    return true;
				}
				public Boolean ram_gbIsKey(){
				    return false;
				}
				public Integer ram_gbLength(){
				    return 10;
				}
				public Integer ram_gbPrecision(){
				    return 0;
				}
				public String ram_gbDefault(){
				
					return null;
				
				}
				public String ram_gbComment(){
				
				    return "";
				
				}
				public String ram_gbPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ram_gbOriginalDbColumnName(){
				
					return "ram_gb";
				
				}

				
			    public Integer storage_gb;

				public Integer getStorage_gb () {
					return this.storage_gb;
				}

				public Boolean storage_gbIsNullable(){
				    return true;
				}
				public Boolean storage_gbIsKey(){
				    return false;
				}
				public Integer storage_gbLength(){
				    return 10;
				}
				public Integer storage_gbPrecision(){
				    return 0;
				}
				public String storage_gbDefault(){
				
					return null;
				
				}
				public String storage_gbComment(){
				
				    return "";
				
				}
				public String storage_gbPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String storage_gbOriginalDbColumnName(){
				
					return "storage_gb";
				
				}

				
			    public Integer camera_mp;

				public Integer getCamera_mp () {
					return this.camera_mp;
				}

				public Boolean camera_mpIsNullable(){
				    return true;
				}
				public Boolean camera_mpIsKey(){
				    return false;
				}
				public Integer camera_mpLength(){
				    return 3;
				}
				public Integer camera_mpPrecision(){
				    return 0;
				}
				public String camera_mpDefault(){
				
					return null;
				
				}
				public String camera_mpComment(){
				
				    return "";
				
				}
				public String camera_mpPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String camera_mpOriginalDbColumnName(){
				
					return "camera_mp";
				
				}

				
			    public Integer battery_mah;

				public Integer getBattery_mah () {
					return this.battery_mah;
				}

				public Boolean battery_mahIsNullable(){
				    return true;
				}
				public Boolean battery_mahIsKey(){
				    return false;
				}
				public Integer battery_mahLength(){
				    return 4;
				}
				public Integer battery_mahPrecision(){
				    return 0;
				}
				public String battery_mahDefault(){
				
					return null;
				
				}
				public String battery_mahComment(){
				
				    return "";
				
				}
				public String battery_mahPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String battery_mahOriginalDbColumnName(){
				
					return "battery_mah";
				
				}

				
			    public Float display_size_inch;

				public Float getDisplay_size_inch () {
					return this.display_size_inch;
				}

				public Boolean display_size_inchIsNullable(){
				    return true;
				}
				public Boolean display_size_inchIsKey(){
				    return false;
				}
				public Integer display_size_inchLength(){
				    return 3;
				}
				public Integer display_size_inchPrecision(){
				    return 2;
				}
				public String display_size_inchDefault(){
				
					return null;
				
				}
				public String display_size_inchComment(){
				
				    return "";
				
				}
				public String display_size_inchPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String display_size_inchOriginalDbColumnName(){
				
					return "display_size_inch";
				
				}

				
			    public Integer charging_watt;

				public Integer getCharging_watt () {
					return this.charging_watt;
				}

				public Boolean charging_wattIsNullable(){
				    return true;
				}
				public Boolean charging_wattIsKey(){
				    return false;
				}
				public Integer charging_wattLength(){
				    return 3;
				}
				public Integer charging_wattPrecision(){
				    return 0;
				}
				public String charging_wattDefault(){
				
					return null;
				
				}
				public String charging_wattComment(){
				
				    return "";
				
				}
				public String charging_wattPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String charging_wattOriginalDbColumnName(){
				
					return "charging_watt";
				
				}

				
			    public String support5g;

				public String getSupport5g () {
					return this.support5g;
				}

				public Boolean support5gIsNullable(){
				    return true;
				}
				public Boolean support5gIsKey(){
				    return false;
				}
				public Integer support5gLength(){
				    return 3;
				}
				public Integer support5gPrecision(){
				    return 0;
				}
				public String support5gDefault(){
				
					return null;
				
				}
				public String support5gComment(){
				
				    return "";
				
				}
				public String support5gPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String support5gOriginalDbColumnName(){
				
					return "support5g";
				
				}

				
			    public String os;

				public String getOs () {
					return this.os;
				}

				public Boolean osIsNullable(){
				    return true;
				}
				public Boolean osIsKey(){
				    return false;
				}
				public Integer osLength(){
				    return 7;
				}
				public Integer osPrecision(){
				    return 0;
				}
				public String osDefault(){
				
					return null;
				
				}
				public String osComment(){
				
				    return "";
				
				}
				public String osPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String osOriginalDbColumnName(){
				
					return "os";
				
				}

				
			    public String processor;

				public String getProcessor () {
					return this.processor;
				}

				public Boolean processorIsNullable(){
				    return true;
				}
				public Boolean processorIsKey(){
				    return false;
				}
				public Integer processorLength(){
				    return 19;
				}
				public Integer processorPrecision(){
				    return 0;
				}
				public String processorDefault(){
				
					return null;
				
				}
				public String processorComment(){
				
				    return "";
				
				}
				public String processorPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String processorOriginalDbColumnName(){
				
					return "processor";
				
				}

				
			    public Float rating;

				public Float getRating () {
					return this.rating;
				}

				public Boolean ratingIsNullable(){
				    return true;
				}
				public Boolean ratingIsKey(){
				    return false;
				}
				public Integer ratingLength(){
				    return 3;
				}
				public Integer ratingPrecision(){
				    return 2;
				}
				public String ratingDefault(){
				
					return null;
				
				}
				public String ratingComment(){
				
				    return "";
				
				}
				public String ratingPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ratingOriginalDbColumnName(){
				
					return "rating";
				
				}

				
			    public String release_month;

				public String getRelease_month () {
					return this.release_month;
				}

				public Boolean release_monthIsNullable(){
				    return true;
				}
				public Boolean release_monthIsKey(){
				    return false;
				}
				public Integer release_monthLength(){
				    return 9;
				}
				public Integer release_monthPrecision(){
				    return 0;
				}
				public String release_monthDefault(){
				
					return null;
				
				}
				public String release_monthComment(){
				
				    return "";
				
				}
				public String release_monthPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String release_monthOriginalDbColumnName(){
				
					return "release_month";
				
				}

				
			    public Integer year;

				public Integer getYear () {
					return this.year;
				}

				public Boolean yearIsNullable(){
				    return true;
				}
				public Boolean yearIsKey(){
				    return false;
				}
				public Integer yearLength(){
				    return 4;
				}
				public Integer yearPrecision(){
				    return 0;
				}
				public String yearDefault(){
				
					return null;
				
				}
				public String yearComment(){
				
				    return "";
				
				}
				public String yearPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String yearOriginalDbColumnName(){
				
					return "year";
				
				}

				
			    public Float prix_cfa;

				public Float getPrix_cfa () {
					return this.prix_cfa;
				}

				public Boolean prix_cfaIsNullable(){
				    return true;
				}
				public Boolean prix_cfaIsKey(){
				    return false;
				}
				public Integer prix_cfaLength(){
				    return null;
				}
				public Integer prix_cfaPrecision(){
				    return null;
				}
				public String prix_cfaDefault(){
				
					return null;
				
				}
				public String prix_cfaComment(){
				
				    return "";
				
				}
				public String prix_cfaPattern(){
				
					return "";
				
				}
				public String prix_cfaOriginalDbColumnName(){
				
					return "prix_cfa";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.brand = readString(dis);
					
					this.model = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_usd = null;
           				} else {
           			    	this.prix_usd = dis.readFloat();
           				}
					
						this.ram_gb = readInteger(dis);
					
						this.storage_gb = readInteger(dis);
					
						this.camera_mp = readInteger(dis);
					
						this.battery_mah = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.display_size_inch = null;
           				} else {
           			    	this.display_size_inch = dis.readFloat();
           				}
					
						this.charging_watt = readInteger(dis);
					
					this.support5g = readString(dis);
					
					this.os = readString(dis);
					
					this.processor = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.rating = null;
           				} else {
           			    	this.rating = dis.readFloat();
           				}
					
					this.release_month = readString(dis);
					
						this.year = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_cfa = null;
           				} else {
           			    	this.prix_cfa = dis.readFloat();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.brand = readString(dis);
					
					this.model = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_usd = null;
           				} else {
           			    	this.prix_usd = dis.readFloat();
           				}
					
						this.ram_gb = readInteger(dis);
					
						this.storage_gb = readInteger(dis);
					
						this.camera_mp = readInteger(dis);
					
						this.battery_mah = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.display_size_inch = null;
           				} else {
           			    	this.display_size_inch = dis.readFloat();
           				}
					
						this.charging_watt = readInteger(dis);
					
					this.support5g = readString(dis);
					
					this.os = readString(dis);
					
					this.processor = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.rating = null;
           				} else {
           			    	this.rating = dis.readFloat();
           				}
					
					this.release_month = readString(dis);
					
						this.year = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_cfa = null;
           				} else {
           			    	this.prix_cfa = dis.readFloat();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.brand,dos);
					
					// String
				
						writeString(this.model,dos);
					
					// Float
				
						if(this.prix_usd == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_usd);
		            	}
					
					// Integer
				
						writeInteger(this.ram_gb,dos);
					
					// Integer
				
						writeInteger(this.storage_gb,dos);
					
					// Integer
				
						writeInteger(this.camera_mp,dos);
					
					// Integer
				
						writeInteger(this.battery_mah,dos);
					
					// Float
				
						if(this.display_size_inch == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.display_size_inch);
		            	}
					
					// Integer
				
						writeInteger(this.charging_watt,dos);
					
					// String
				
						writeString(this.support5g,dos);
					
					// String
				
						writeString(this.os,dos);
					
					// String
				
						writeString(this.processor,dos);
					
					// Float
				
						if(this.rating == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.rating);
		            	}
					
					// String
				
						writeString(this.release_month,dos);
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// Float
				
						if(this.prix_cfa == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_cfa);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.brand,dos);
					
					// String
				
						writeString(this.model,dos);
					
					// Float
				
						if(this.prix_usd == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_usd);
		            	}
					
					// Integer
				
						writeInteger(this.ram_gb,dos);
					
					// Integer
				
						writeInteger(this.storage_gb,dos);
					
					// Integer
				
						writeInteger(this.camera_mp,dos);
					
					// Integer
				
						writeInteger(this.battery_mah,dos);
					
					// Float
				
						if(this.display_size_inch == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.display_size_inch);
		            	}
					
					// Integer
				
						writeInteger(this.charging_watt,dos);
					
					// String
				
						writeString(this.support5g,dos);
					
					// String
				
						writeString(this.os,dos);
					
					// String
				
						writeString(this.processor,dos);
					
					// Float
				
						if(this.rating == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.rating);
		            	}
					
					// String
				
						writeString(this.release_month,dos);
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// Float
				
						if(this.prix_cfa == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_cfa);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("brand="+brand);
		sb.append(",model="+model);
		sb.append(",prix_usd="+String.valueOf(prix_usd));
		sb.append(",ram_gb="+String.valueOf(ram_gb));
		sb.append(",storage_gb="+String.valueOf(storage_gb));
		sb.append(",camera_mp="+String.valueOf(camera_mp));
		sb.append(",battery_mah="+String.valueOf(battery_mah));
		sb.append(",display_size_inch="+String.valueOf(display_size_inch));
		sb.append(",charging_watt="+String.valueOf(charging_watt));
		sb.append(",support5g="+support5g);
		sb.append(",os="+os);
		sb.append(",processor="+processor);
		sb.append(",rating="+String.valueOf(rating));
		sb.append(",release_month="+release_month);
		sb.append(",year="+String.valueOf(year));
		sb.append(",prix_cfa="+String.valueOf(prix_cfa));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tFileInputDelimited_2Struct implements routines.system.IPersistableRow<after_tFileInputDelimited_2Struct> {
    final static byte[] commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];
    static byte[] commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];

	
			    public String brand;

				public String getBrand () {
					return this.brand;
				}

				public Boolean brandIsNullable(){
				    return true;
				}
				public Boolean brandIsKey(){
				    return false;
				}
				public Integer brandLength(){
				    return 50;
				}
				public Integer brandPrecision(){
				    return 0;
				}
				public String brandDefault(){
				
					return null;
				
				}
				public String brandComment(){
				
				    return "";
				
				}
				public String brandPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String brandOriginalDbColumnName(){
				
					return "brand";
				
				}

				
			    public String model;

				public String getModel () {
					return this.model;
				}

				public Boolean modelIsNullable(){
				    return true;
				}
				public Boolean modelIsKey(){
				    return false;
				}
				public Integer modelLength(){
				    return 50;
				}
				public Integer modelPrecision(){
				    return 0;
				}
				public String modelDefault(){
				
					return null;
				
				}
				public String modelComment(){
				
				    return "";
				
				}
				public String modelPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String modelOriginalDbColumnName(){
				
					return "model";
				
				}

				
			    public Float prix_usd;

				public Float getPrix_usd () {
					return this.prix_usd;
				}

				public Boolean prix_usdIsNullable(){
				    return true;
				}
				public Boolean prix_usdIsKey(){
				    return false;
				}
				public Integer prix_usdLength(){
				    return 6;
				}
				public Integer prix_usdPrecision(){
				    return 0;
				}
				public String prix_usdDefault(){
				
					return null;
				
				}
				public String prix_usdComment(){
				
				    return "";
				
				}
				public String prix_usdPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String prix_usdOriginalDbColumnName(){
				
					return "prix_usd";
				
				}

				
			    public Integer ram_gb;

				public Integer getRam_gb () {
					return this.ram_gb;
				}

				public Boolean ram_gbIsNullable(){
				    return true;
				}
				public Boolean ram_gbIsKey(){
				    return false;
				}
				public Integer ram_gbLength(){
				    return 10;
				}
				public Integer ram_gbPrecision(){
				    return 0;
				}
				public String ram_gbDefault(){
				
					return null;
				
				}
				public String ram_gbComment(){
				
				    return "";
				
				}
				public String ram_gbPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ram_gbOriginalDbColumnName(){
				
					return "ram_gb";
				
				}

				
			    public Integer storage_gb;

				public Integer getStorage_gb () {
					return this.storage_gb;
				}

				public Boolean storage_gbIsNullable(){
				    return true;
				}
				public Boolean storage_gbIsKey(){
				    return false;
				}
				public Integer storage_gbLength(){
				    return 10;
				}
				public Integer storage_gbPrecision(){
				    return 0;
				}
				public String storage_gbDefault(){
				
					return null;
				
				}
				public String storage_gbComment(){
				
				    return "";
				
				}
				public String storage_gbPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String storage_gbOriginalDbColumnName(){
				
					return "storage_gb";
				
				}

				
			    public Integer camera_mp;

				public Integer getCamera_mp () {
					return this.camera_mp;
				}

				public Boolean camera_mpIsNullable(){
				    return true;
				}
				public Boolean camera_mpIsKey(){
				    return false;
				}
				public Integer camera_mpLength(){
				    return 3;
				}
				public Integer camera_mpPrecision(){
				    return 0;
				}
				public String camera_mpDefault(){
				
					return null;
				
				}
				public String camera_mpComment(){
				
				    return "";
				
				}
				public String camera_mpPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String camera_mpOriginalDbColumnName(){
				
					return "camera_mp";
				
				}

				
			    public Integer battery_mah;

				public Integer getBattery_mah () {
					return this.battery_mah;
				}

				public Boolean battery_mahIsNullable(){
				    return true;
				}
				public Boolean battery_mahIsKey(){
				    return false;
				}
				public Integer battery_mahLength(){
				    return 4;
				}
				public Integer battery_mahPrecision(){
				    return 0;
				}
				public String battery_mahDefault(){
				
					return null;
				
				}
				public String battery_mahComment(){
				
				    return "";
				
				}
				public String battery_mahPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String battery_mahOriginalDbColumnName(){
				
					return "battery_mah";
				
				}

				
			    public Float display_size_inch;

				public Float getDisplay_size_inch () {
					return this.display_size_inch;
				}

				public Boolean display_size_inchIsNullable(){
				    return true;
				}
				public Boolean display_size_inchIsKey(){
				    return false;
				}
				public Integer display_size_inchLength(){
				    return 3;
				}
				public Integer display_size_inchPrecision(){
				    return 2;
				}
				public String display_size_inchDefault(){
				
					return null;
				
				}
				public String display_size_inchComment(){
				
				    return "";
				
				}
				public String display_size_inchPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String display_size_inchOriginalDbColumnName(){
				
					return "display_size_inch";
				
				}

				
			    public Integer charging_watt;

				public Integer getCharging_watt () {
					return this.charging_watt;
				}

				public Boolean charging_wattIsNullable(){
				    return true;
				}
				public Boolean charging_wattIsKey(){
				    return false;
				}
				public Integer charging_wattLength(){
				    return 3;
				}
				public Integer charging_wattPrecision(){
				    return 0;
				}
				public String charging_wattDefault(){
				
					return null;
				
				}
				public String charging_wattComment(){
				
				    return "";
				
				}
				public String charging_wattPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String charging_wattOriginalDbColumnName(){
				
					return "charging_watt";
				
				}

				
			    public String support5g;

				public String getSupport5g () {
					return this.support5g;
				}

				public Boolean support5gIsNullable(){
				    return true;
				}
				public Boolean support5gIsKey(){
				    return false;
				}
				public Integer support5gLength(){
				    return 3;
				}
				public Integer support5gPrecision(){
				    return 0;
				}
				public String support5gDefault(){
				
					return null;
				
				}
				public String support5gComment(){
				
				    return "";
				
				}
				public String support5gPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String support5gOriginalDbColumnName(){
				
					return "support5g";
				
				}

				
			    public String os;

				public String getOs () {
					return this.os;
				}

				public Boolean osIsNullable(){
				    return true;
				}
				public Boolean osIsKey(){
				    return false;
				}
				public Integer osLength(){
				    return 7;
				}
				public Integer osPrecision(){
				    return 0;
				}
				public String osDefault(){
				
					return null;
				
				}
				public String osComment(){
				
				    return "";
				
				}
				public String osPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String osOriginalDbColumnName(){
				
					return "os";
				
				}

				
			    public String processor;

				public String getProcessor () {
					return this.processor;
				}

				public Boolean processorIsNullable(){
				    return true;
				}
				public Boolean processorIsKey(){
				    return false;
				}
				public Integer processorLength(){
				    return 19;
				}
				public Integer processorPrecision(){
				    return 0;
				}
				public String processorDefault(){
				
					return null;
				
				}
				public String processorComment(){
				
				    return "";
				
				}
				public String processorPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String processorOriginalDbColumnName(){
				
					return "processor";
				
				}

				
			    public Float rating;

				public Float getRating () {
					return this.rating;
				}

				public Boolean ratingIsNullable(){
				    return true;
				}
				public Boolean ratingIsKey(){
				    return false;
				}
				public Integer ratingLength(){
				    return 3;
				}
				public Integer ratingPrecision(){
				    return 2;
				}
				public String ratingDefault(){
				
					return null;
				
				}
				public String ratingComment(){
				
				    return "";
				
				}
				public String ratingPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ratingOriginalDbColumnName(){
				
					return "rating";
				
				}

				
			    public String release_month;

				public String getRelease_month () {
					return this.release_month;
				}

				public Boolean release_monthIsNullable(){
				    return true;
				}
				public Boolean release_monthIsKey(){
				    return false;
				}
				public Integer release_monthLength(){
				    return 9;
				}
				public Integer release_monthPrecision(){
				    return 0;
				}
				public String release_monthDefault(){
				
					return null;
				
				}
				public String release_monthComment(){
				
				    return "";
				
				}
				public String release_monthPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String release_monthOriginalDbColumnName(){
				
					return "release_month";
				
				}

				
			    public Integer year;

				public Integer getYear () {
					return this.year;
				}

				public Boolean yearIsNullable(){
				    return true;
				}
				public Boolean yearIsKey(){
				    return false;
				}
				public Integer yearLength(){
				    return 4;
				}
				public Integer yearPrecision(){
				    return 0;
				}
				public String yearDefault(){
				
					return null;
				
				}
				public String yearComment(){
				
				    return "";
				
				}
				public String yearPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String yearOriginalDbColumnName(){
				
					return "year";
				
				}

				
			    public Float prix_cfa;

				public Float getPrix_cfa () {
					return this.prix_cfa;
				}

				public Boolean prix_cfaIsNullable(){
				    return true;
				}
				public Boolean prix_cfaIsKey(){
				    return false;
				}
				public Integer prix_cfaLength(){
				    return null;
				}
				public Integer prix_cfaPrecision(){
				    return null;
				}
				public String prix_cfaDefault(){
				
					return null;
				
				}
				public String prix_cfaComment(){
				
				    return "";
				
				}
				public String prix_cfaPattern(){
				
					return "";
				
				}
				public String prix_cfaOriginalDbColumnName(){
				
					return "prix_cfa";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.brand = readString(dis);
					
					this.model = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_usd = null;
           				} else {
           			    	this.prix_usd = dis.readFloat();
           				}
					
						this.ram_gb = readInteger(dis);
					
						this.storage_gb = readInteger(dis);
					
						this.camera_mp = readInteger(dis);
					
						this.battery_mah = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.display_size_inch = null;
           				} else {
           			    	this.display_size_inch = dis.readFloat();
           				}
					
						this.charging_watt = readInteger(dis);
					
					this.support5g = readString(dis);
					
					this.os = readString(dis);
					
					this.processor = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.rating = null;
           				} else {
           			    	this.rating = dis.readFloat();
           				}
					
					this.release_month = readString(dis);
					
						this.year = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_cfa = null;
           				} else {
           			    	this.prix_cfa = dis.readFloat();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.brand = readString(dis);
					
					this.model = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_usd = null;
           				} else {
           			    	this.prix_usd = dis.readFloat();
           				}
					
						this.ram_gb = readInteger(dis);
					
						this.storage_gb = readInteger(dis);
					
						this.camera_mp = readInteger(dis);
					
						this.battery_mah = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.display_size_inch = null;
           				} else {
           			    	this.display_size_inch = dis.readFloat();
           				}
					
						this.charging_watt = readInteger(dis);
					
					this.support5g = readString(dis);
					
					this.os = readString(dis);
					
					this.processor = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.rating = null;
           				} else {
           			    	this.rating = dis.readFloat();
           				}
					
					this.release_month = readString(dis);
					
						this.year = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_cfa = null;
           				} else {
           			    	this.prix_cfa = dis.readFloat();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.brand,dos);
					
					// String
				
						writeString(this.model,dos);
					
					// Float
				
						if(this.prix_usd == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_usd);
		            	}
					
					// Integer
				
						writeInteger(this.ram_gb,dos);
					
					// Integer
				
						writeInteger(this.storage_gb,dos);
					
					// Integer
				
						writeInteger(this.camera_mp,dos);
					
					// Integer
				
						writeInteger(this.battery_mah,dos);
					
					// Float
				
						if(this.display_size_inch == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.display_size_inch);
		            	}
					
					// Integer
				
						writeInteger(this.charging_watt,dos);
					
					// String
				
						writeString(this.support5g,dos);
					
					// String
				
						writeString(this.os,dos);
					
					// String
				
						writeString(this.processor,dos);
					
					// Float
				
						if(this.rating == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.rating);
		            	}
					
					// String
				
						writeString(this.release_month,dos);
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// Float
				
						if(this.prix_cfa == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_cfa);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.brand,dos);
					
					// String
				
						writeString(this.model,dos);
					
					// Float
				
						if(this.prix_usd == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_usd);
		            	}
					
					// Integer
				
						writeInteger(this.ram_gb,dos);
					
					// Integer
				
						writeInteger(this.storage_gb,dos);
					
					// Integer
				
						writeInteger(this.camera_mp,dos);
					
					// Integer
				
						writeInteger(this.battery_mah,dos);
					
					// Float
				
						if(this.display_size_inch == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.display_size_inch);
		            	}
					
					// Integer
				
						writeInteger(this.charging_watt,dos);
					
					// String
				
						writeString(this.support5g,dos);
					
					// String
				
						writeString(this.os,dos);
					
					// String
				
						writeString(this.processor,dos);
					
					// Float
				
						if(this.rating == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.rating);
		            	}
					
					// String
				
						writeString(this.release_month,dos);
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// Float
				
						if(this.prix_cfa == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_cfa);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("brand="+brand);
		sb.append(",model="+model);
		sb.append(",prix_usd="+String.valueOf(prix_usd));
		sb.append(",ram_gb="+String.valueOf(ram_gb));
		sb.append(",storage_gb="+String.valueOf(storage_gb));
		sb.append(",camera_mp="+String.valueOf(camera_mp));
		sb.append(",battery_mah="+String.valueOf(battery_mah));
		sb.append(",display_size_inch="+String.valueOf(display_size_inch));
		sb.append(",charging_watt="+String.valueOf(charging_watt));
		sb.append(",support5g="+support5g);
		sb.append(",os="+os);
		sb.append(",processor="+processor);
		sb.append(",rating="+String.valueOf(rating));
		sb.append(",release_month="+release_month);
		sb.append(",year="+String.valueOf(year));
		sb.append(",prix_cfa="+String.valueOf(prix_cfa));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(after_tFileInputDelimited_2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tFileInputDelimited_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tDBInput_1Process(globalMap);
		tDBInput_2Process(globalMap);

		row1Struct row1 = new row1Struct();
csv_mysqlStruct csv_mysql = new csv_mysqlStruct();
Final_dataStruct Final_data = new Final_dataStruct();
row4Struct row4 = new row4Struct();
row6Struct row6 = new row6Struct();





	
	/**
	 * [tLogRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_1", false);
		start_Hash.put("tLogRow_1", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_1";
	
	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"csv_mysql");
					}
				
		int tos_count_tLogRow_1 = 0;
		

	///////////////////////
	
         class Util_tLogRow_1 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[11];

        public void addRow(String[] row) {

            for (int i = 0; i < 11; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 10 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 10 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%8$-");
        			        sbformat.append(colLengths[7]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%9$-");
        			        sbformat.append(colLengths[8]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%10$-");
        			        sbformat.append(colLengths[9]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%11$-");
        			        sbformat.append(colLengths[10]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[10] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_1 util_tLogRow_1 = new Util_tLogRow_1();
        util_tLogRow_1.setTableName("tLogRow_1");
        util_tLogRow_1.addRow(new String[]{"marque","modele","prix_usd","ram_gb","storage_gb","support5g","os","date_sortie","prix_cfa","vendeur","Pays",});        
 		StringBuilder strBuffer_tLogRow_1 = null;
		int nb_line_tLogRow_1 = 0;
///////////////////////    			



 



/**
 * [tLogRow_1 begin ] stop
 */






	
	/**
	 * [tLogRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_2", false);
		start_Hash.put("tLogRow_2", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_2";
	
	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row6");
					}
				
		int tos_count_tLogRow_2 = 0;
		

	///////////////////////
	
         class Util_tLogRow_2 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[11];

        public void addRow(String[] row) {

            for (int i = 0; i < 11; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 10 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 10 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%8$-");
        			        sbformat.append(colLengths[7]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%9$-");
        			        sbformat.append(colLengths[8]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%10$-");
        			        sbformat.append(colLengths[9]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%11$-");
        			        sbformat.append(colLengths[10]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[10] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_2 util_tLogRow_2 = new Util_tLogRow_2();
        util_tLogRow_2.setTableName("tLogRow_2");
        util_tLogRow_2.addRow(new String[]{"marque","modele","prix_usd","ram_gb","storage_gb","support5g","os","date_sortie","prix_cfa","vendeur","Pays",});        
 		StringBuilder strBuffer_tLogRow_2 = null;
		int nb_line_tLogRow_2 = 0;
///////////////////////    			



 



/**
 * [tLogRow_2 begin ] stop
 */



	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row4");
					}
				
		int tos_count_tDBOutput_1 = 0;
		





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = "public";
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("Cible_postgres");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("Cible_postgres");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_1 = "jdbc:postgresql://"+"localhost"+":"+"5432"+"/"+"Phones_cible";
    dbUser_tDBOutput_1 = "postgres";
 
	final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:ea/GuFQHnCGX0PiocVUT6fXcg6M1hrMHzSdlo1NMUM3D");

    String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;

    conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1,dbUser_tDBOutput_1,dbPwd_tDBOutput_1);
	
	resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
        conn_tDBOutput_1.setAutoCommit(false);
        int commitEvery_tDBOutput_1 = 1000;
        int commitCounter_tDBOutput_1 = 0;


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
        java.lang.StringBuilder sb_tDBOutput_1 = new java.lang.StringBuilder();
        sb_tDBOutput_1.append("INSERT INTO \"").append(tableName_tDBOutput_1).append("\" (\"marque\",\"modele\",\"prix_usd\",\"ram_gb\",\"storage_gb\",\"support5g\",\"os\",\"date_sortie\",\"prix_cfa\",\"vendeur\",\"Pays\") VALUES (?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_1 = sb_tDBOutput_1.toString();
        
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tJavaRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_2", false);
		start_Hash.put("tJavaRow_2", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_2";
	
	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"Final_data");
					}
				
		int tos_count_tJavaRow_2 = 0;
		

int nb_line_tJavaRow_2 = 0;

 



/**
 * [tJavaRow_2 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";
	
	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row1");
					}
				
		int tos_count_tMap_1 = 0;
		




// ###############################
// # Lookup's keys initialization
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct> tHash_Lookup_row2 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct>) 
					globalMap.get( "tHash_Lookup_row2" ))
					;					
					
	

row2Struct row2HashKey = new row2Struct();
row2Struct row2Default = new row2Struct();
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct> tHash_Lookup_row3 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct>) 
					globalMap.get( "tHash_Lookup_row3" ))
					;					
					
	

row3Struct row3HashKey = new row3Struct();
row3Struct row3Default = new row3Struct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
csv_mysqlStruct csv_mysql_tmp = new csv_mysqlStruct();
Final_dataStruct Final_data_tmp = new Final_dataStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_2", false);
		start_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_2";
	
	
		int tos_count_tFileInputDelimited_2 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_2 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_2 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_2 = null;
				int limit_tFileInputDelimited_2 = -1;
				try{
					
						Object filename_tFileInputDelimited_2 = "C:/Users/Gyslain/Documents/Documents/talend_project/Phones.csv";
						if(filename_tFileInputDelimited_2 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_2 = 0, random_value_tFileInputDelimited_2 = -1;
			if(footer_value_tFileInputDelimited_2 >0 || random_value_tFileInputDelimited_2 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_2 = new org.talend.fileprocess.FileInputDelimited("C:/Users/Gyslain/Documents/Documents/talend_project/Phones.csv", "UTF-8",",","\n",false,1,0,
									limit_tFileInputDelimited_2
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_2!=null && fid_tFileInputDelimited_2.nextRecord()) {
						rowstate_tFileInputDelimited_2.reset();
						
			    						row1 = null;			
												
									boolean whetherReject_tFileInputDelimited_2 = false;
									row1 = new row1Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_2 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_2 = 0;
					
							row1.brand = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 1;
					
							row1.model = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 2;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row1.prix_usd = ParserUtils.parseTo_Float(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"prix_usd", "row1", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row1.prix_usd = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_2 = 3;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row1.ram_gb = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"ram_gb", "row1", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row1.ram_gb = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_2 = 4;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row1.storage_gb = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"storage_gb", "row1", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row1.storage_gb = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_2 = 5;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row1.camera_mp = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"camera_mp", "row1", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row1.camera_mp = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_2 = 6;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row1.battery_mah = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"battery_mah", "row1", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row1.battery_mah = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_2 = 7;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row1.display_size_inch = ParserUtils.parseTo_Float(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"display_size_inch", "row1", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row1.display_size_inch = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_2 = 8;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row1.charging_watt = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"charging_watt", "row1", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row1.charging_watt = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_2 = 9;
					
							row1.support5g = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 10;
					
							row1.os = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 11;
					
							row1.processor = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 12;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row1.rating = ParserUtils.parseTo_Float(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"rating", "row1", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row1.rating = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_2 = 13;
					
							row1.release_month = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 14;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row1.year = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"year", "row1", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row1.year = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_2 = 15;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row1.prix_cfa = ParserUtils.parseTo_Float(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"prix_cfa", "row1", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row1.prix_cfa = null;
								
							
						}
					
				
				
										
										if(rowstate_tFileInputDelimited_2.getException()!=null) {
											throw rowstate_tFileInputDelimited_2.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_2 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row1 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_2 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";
	
	

 


	tos_count_tFileInputDelimited_2++;

/**
 * [tFileInputDelimited_2 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";
	
	

 



/**
 * [tFileInputDelimited_2 process_data_begin ] stop
 */
// Start of branch "row1"
if(row1 != null) { 



	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row1"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
						row2Struct row2 = null;
					
						row3Struct row3 = null;
					
		// ###############################
		// # Input tables (lookups)
		
		boolean rejectedInnerJoin_tMap_1 = false;
		boolean mainRowRejected_tMap_1 = false;
		

				///////////////////////////////////////////////
				// Starting Lookup Table "row2" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow2 = false;
       		  	    	
       		  	    	
 							row2Struct row2ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row2HashKey.brand = row1.brand;
                        		    		

								
		                        	row2HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row2.lookup( row2HashKey );

	  							

	  							

 								
								  
								  if(!tHash_Lookup_row2.hasNext()) { // G_TM_M_090

  								
		  				
	  								
			  							rejectedInnerJoin_tMap_1 = true;
	  								
						
									
  									  		
 								
								  
								  } // G_TM_M_090

  								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row2 != null && tHash_Lookup_row2.getCount(row2HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row2' and it contains more one result from keys :  row2.brand = '" + row2HashKey.brand + "'");
								} // G 071
							

							
                    		  	 
							   
                    		  	 
	       		  	    	row2Struct fromLookup_row2 = null;
							row2 = row2Default;
										 
							
								 
							
							
								if (tHash_Lookup_row2 !=null && tHash_Lookup_row2.hasNext()) { // G 099
								
							
								
								fromLookup_row2 = tHash_Lookup_row2.next();

							
							
								} // G 099
							
							

							if(fromLookup_row2 != null) {
								row2 = fromLookup_row2;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	           	
	            	
	            	
	            

				///////////////////////////////////////////////
				// Starting Lookup Table "row3" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow3 = false;
       		  	    	
       		  	    	
 							row3Struct row3ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row3HashKey.brand = row1.brand ;
                        		    		

								
		                        	row3HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row3.lookup( row3HashKey );

	  							

	  							

 								
								  
								  if(!tHash_Lookup_row3.hasNext()) { // G_TM_M_090

  								
		  				
	  								
			  							rejectedInnerJoin_tMap_1 = true;
	  								
						
									
  									  		
 								
								  
								  } // G_TM_M_090

  								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row3 != null && tHash_Lookup_row3.getCount(row3HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row3' and it contains more one result from keys :  row3.brand = '" + row3HashKey.brand + "'");
								} // G 071
							

							
                    		  	 
							   
                    		  	 
	       		  	    	row3Struct fromLookup_row3 = null;
							row3 = row3Default;
										 
							
								 
							
							
								if (tHash_Lookup_row3 !=null && tHash_Lookup_row3.hasNext()) { // G 099
								
							
								
								fromLookup_row3 = tHash_Lookup_row3.next();

							
							
								} // G 099
							
							

							if(fromLookup_row3 != null) {
								row3 = fromLookup_row3;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

csv_mysql = null;
Final_data = null;

if(!rejectedInnerJoin_tMap_1 ) {

// # Output table : 'csv_mysql'
csv_mysql_tmp.marque = row1.brand ;
csv_mysql_tmp.modele = row1.model ;
csv_mysql_tmp.prix_usd = row1.prix_usd ;
csv_mysql_tmp.ram_gb = row1.ram_gb ;
csv_mysql_tmp.storage_gb = row1.storage_gb ;
csv_mysql_tmp.support5g = row1.support5g ;
csv_mysql_tmp.os = row1.os ;
csv_mysql_tmp.date_sortie = row1.release_month + " " + row1.year;
csv_mysql_tmp.prix_cfa = row1.prix_cfa =  row1.prix_usd * 650;
csv_mysql_tmp.vendeur = row2.vendeur ;
csv_mysql_tmp.Pays = row3.country ;
csv_mysql = csv_mysql_tmp;

// # Output table : 'Final_data'
Final_data_tmp.marque = row1.brand  ;
Final_data_tmp.modele = row1.model  ;
Final_data_tmp.prix_usd = row1.prix_usd  ;
Final_data_tmp.ram_gb = row1.ram_gb  ;
Final_data_tmp.storage_gb = row1.storage_gb  ;
Final_data_tmp.support5g = row1.support5g  ;
Final_data_tmp.os = row1.os  ;
Final_data_tmp.date_sortie = row1.release_month + " " + row1.year ;
Final_data_tmp.prix_cfa = row1.prix_cfa =  row1.prix_usd * 650 ;
Final_data_tmp.vendeur = row2.vendeur  ;
Final_data_tmp.Pays = row3.country  ;
Final_data = Final_data_tmp;
}  // closing inner join bracket (2)
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "csv_mysql"
if(csv_mysql != null) { 



	
	/**
	 * [tLogRow_1 main ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"csv_mysql"
						
						);
					}
					
///////////////////////		
						

				
				String[] row_tLogRow_1 = new String[11];
   				
	    		if(csv_mysql.marque != null) { //              
                 row_tLogRow_1[0]=    						    
				                String.valueOf(csv_mysql.marque)			
					          ;	
							
	    		} //			
    			   				
	    		if(csv_mysql.modele != null) { //              
                 row_tLogRow_1[1]=    						    
				                String.valueOf(csv_mysql.modele)			
					          ;	
							
	    		} //			
    			   				
	    		if(csv_mysql.prix_usd != null) { //              
                 row_tLogRow_1[2]=    						
								FormatterUtils.formatUnwithE(csv_mysql.prix_usd)
					          ;	
							
	    		} //			
    			   				
	    		if(csv_mysql.ram_gb != null) { //              
                 row_tLogRow_1[3]=    						    
				                String.valueOf(csv_mysql.ram_gb)			
					          ;	
							
	    		} //			
    			   				
	    		if(csv_mysql.storage_gb != null) { //              
                 row_tLogRow_1[4]=    						    
				                String.valueOf(csv_mysql.storage_gb)			
					          ;	
							
	    		} //			
    			   				
	    		if(csv_mysql.support5g != null) { //              
                 row_tLogRow_1[5]=    						    
				                String.valueOf(csv_mysql.support5g)			
					          ;	
							
	    		} //			
    			   				
	    		if(csv_mysql.os != null) { //              
                 row_tLogRow_1[6]=    						    
				                String.valueOf(csv_mysql.os)			
					          ;	
							
	    		} //			
    			   				
	    		if(csv_mysql.date_sortie != null) { //              
                 row_tLogRow_1[7]=    						    
				                String.valueOf(csv_mysql.date_sortie)			
					          ;	
							
	    		} //			
    			   				
	    		if(csv_mysql.prix_cfa != null) { //              
                 row_tLogRow_1[8]=    						
								FormatterUtils.formatUnwithE(csv_mysql.prix_cfa)
					          ;	
							
	    		} //			
    			   				
	    		if(csv_mysql.vendeur != null) { //              
                 row_tLogRow_1[9]=    						    
				                String.valueOf(csv_mysql.vendeur)			
					          ;	
							
	    		} //			
    			   				
	    		if(csv_mysql.Pays != null) { //              
                 row_tLogRow_1[10]=    						    
				                String.valueOf(csv_mysql.Pays)			
					          ;	
							
	    		} //			
    			 

				util_tLogRow_1.addRow(row_tLogRow_1);	
				nb_line_tLogRow_1++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_tLogRow_1++;

/**
 * [tLogRow_1 main ] stop
 */
	
	/**
	 * [tLogRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	

 



/**
 * [tLogRow_1 process_data_begin ] stop
 */
	
	/**
	 * [tLogRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	

 



/**
 * [tLogRow_1 process_data_end ] stop
 */

} // End of branch "csv_mysql"




// Start of branch "Final_data"
if(Final_data != null) { 



	
	/**
	 * [tJavaRow_2 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";
	
	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"Final_data"
						
						);
					}
					

    //Code généré selon les schémas d'entrée et de sortie
row4.marque = Final_data.marque;
row4.modele = Final_data.modele;
row4.prix_usd = Final_data.prix_usd;
row4.ram_gb = Final_data.ram_gb;
row4.storage_gb = Final_data.storage_gb;
row4.support5g = Final_data.support5g;
row4.os = Final_data.os;
row4.date_sortie = Final_data.date_sortie;
row4.prix_cfa = Final_data.prix_cfa;
row4.vendeur = Final_data.vendeur;
row4.Pays = Final_data.Pays;

Integer count = (Integer) globalMap.get("ROWS_INSERTED");
globalMap.put("ROWS_INSERTED", count + 1);

    nb_line_tJavaRow_2++;   

 


	tos_count_tJavaRow_2++;

/**
 * [tJavaRow_2 main ] stop
 */
	
	/**
	 * [tJavaRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";
	
	

 



/**
 * [tJavaRow_2 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row4"
						
						);
					}
					



            row6 = null;
        whetherReject_tDBOutput_1 = false;
                    if(row4.marque == null) {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(1, row4.marque);
}

                    if(row4.modele == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row4.modele);
}

                    if(row4.prix_usd == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_1.setFloat(3, row4.prix_usd);
}

                    if(row4.ram_gb == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(4, row4.ram_gb);
}

                    if(row4.storage_gb == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(5, row4.storage_gb);
}

                    if(row4.support5g == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, row4.support5g);
}

                    if(row4.os == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(7, row4.os);
}

                    if(row4.date_sortie == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(8, row4.date_sortie);
}

                    if(row4.prix_cfa == null) {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_1.setFloat(9, row4.prix_cfa);
}

                    if(row4.vendeur == null) {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10, row4.vendeur);
}

                    if(row4.Pays == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(11, row4.Pays);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_1++;
    		  
            if(!whetherReject_tDBOutput_1) {
                            row6 = new row6Struct();
                                row6.marque = row4.marque;
                                row6.modele = row4.modele;
                                row6.prix_usd = row4.prix_usd;
                                row6.ram_gb = row4.ram_gb;
                                row6.storage_gb = row4.storage_gb;
                                row6.support5g = row4.support5g;
                                row6.os = row4.os;
                                row6.date_sortie = row4.date_sortie;
                                row6.prix_cfa = row4.prix_cfa;
                                row6.vendeur = row4.vendeur;
                                row6.Pays = row4.Pays;
            }
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_1++;
                if(commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
                if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {
                try {
                		int countSum_tDBOutput_1 = 0;
                		    
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
            	    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
            	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
                batchSizeCounter_tDBOutput_1 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
			    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
			    	String errormessage_tDBOutput_1;
					if (ne_tDBOutput_1 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
						errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
					}else{
						errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
					}
			    	
			    	int countSum_tDBOutput_1 = 0;
					for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
					
			    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
			    	
			    	System.err.println(errormessage_tDBOutput_1);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    }
                    conn_tDBOutput_1.commit();
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_1 = 0;
                    }
                    commitCounter_tDBOutput_1=0;
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
// Start of branch "row6"
if(row6 != null) { 



	
	/**
	 * [tLogRow_2 main ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row6"
						
						);
					}
					
///////////////////////		
						

				
				String[] row_tLogRow_2 = new String[11];
   				
	    		if(row6.marque != null) { //              
                 row_tLogRow_2[0]=    						    
				                String.valueOf(row6.marque)			
					          ;	
							
	    		} //			
    			   				
	    		if(row6.modele != null) { //              
                 row_tLogRow_2[1]=    						    
				                String.valueOf(row6.modele)			
					          ;	
							
	    		} //			
    			   				
	    		if(row6.prix_usd != null) { //              
                 row_tLogRow_2[2]=    						
								FormatterUtils.formatUnwithE(row6.prix_usd)
					          ;	
							
	    		} //			
    			   				
	    		if(row6.ram_gb != null) { //              
                 row_tLogRow_2[3]=    						    
				                String.valueOf(row6.ram_gb)			
					          ;	
							
	    		} //			
    			   				
	    		if(row6.storage_gb != null) { //              
                 row_tLogRow_2[4]=    						    
				                String.valueOf(row6.storage_gb)			
					          ;	
							
	    		} //			
    			   				
	    		if(row6.support5g != null) { //              
                 row_tLogRow_2[5]=    						    
				                String.valueOf(row6.support5g)			
					          ;	
							
	    		} //			
    			   				
	    		if(row6.os != null) { //              
                 row_tLogRow_2[6]=    						    
				                String.valueOf(row6.os)			
					          ;	
							
	    		} //			
    			   				
	    		if(row6.date_sortie != null) { //              
                 row_tLogRow_2[7]=    						    
				                String.valueOf(row6.date_sortie)			
					          ;	
							
	    		} //			
    			   				
	    		if(row6.prix_cfa != null) { //              
                 row_tLogRow_2[8]=    						
								FormatterUtils.formatUnwithE(row6.prix_cfa)
					          ;	
							
	    		} //			
    			   				
	    		if(row6.vendeur != null) { //              
                 row_tLogRow_2[9]=    						    
				                String.valueOf(row6.vendeur)			
					          ;	
							
	    		} //			
    			   				
	    		if(row6.Pays != null) { //              
                 row_tLogRow_2[10]=    						    
				                String.valueOf(row6.Pays)			
					          ;	
							
	    		} //			
    			 

				util_tLogRow_2.addRow(row_tLogRow_2);	
				nb_line_tLogRow_2++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_tLogRow_2++;

/**
 * [tLogRow_2 main ] stop
 */
	
	/**
	 * [tLogRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	

 



/**
 * [tLogRow_2 process_data_begin ] stop
 */
	
	/**
	 * [tLogRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	

 



/**
 * [tLogRow_2 process_data_end ] stop
 */

} // End of branch "row6"




	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tJavaRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";
	
	

 



/**
 * [tJavaRow_2 process_data_end ] stop
 */

} // End of branch "Final_data"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 process_data_end ] stop
 */

} // End of branch "row1"




	
	/**
	 * [tFileInputDelimited_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";
	
	

 



/**
 * [tFileInputDelimited_2 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";
	
	



            }
            }finally{
                if(!((Object)("C:/Users/Gyslain/Documents/Documents/talend_project/Phones.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_2!=null){
                		fid_tFileInputDelimited_2.close();
                	}
                }
                if(fid_tFileInputDelimited_2!=null){
                	globalMap.put("tFileInputDelimited_2_NB_LINE", fid_tFileInputDelimited_2.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_2", true);
end_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());




/**
 * [tFileInputDelimited_2 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_row2 != null) {
						tHash_Lookup_row2.endGet();
					}
					globalMap.remove( "tHash_Lookup_row2" );

					
					
				
					if(tHash_Lookup_row3 != null) {
						tHash_Lookup_row3.endGet();
					}
					globalMap.remove( "tHash_Lookup_row3" );

					
					
				
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row1");
			  	}
			  	
 

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tLogRow_1 end ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_1 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_1 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_1 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_1);
                    }
                    
                    consoleOut_tLogRow_1.println(util_tLogRow_1.format().toString());
                    consoleOut_tLogRow_1.flush();
//////
globalMap.put("tLogRow_1_NB_LINE",nb_line_tLogRow_1);

///////////////////////    			

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"csv_mysql");
			  	}
			  	
 

ok_Hash.put("tLogRow_1", true);
end_Hash.put("tLogRow_1", System.currentTimeMillis());




/**
 * [tLogRow_1 end ] stop
 */




	
	/**
	 * [tJavaRow_2 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";
	
	

globalMap.put("tJavaRow_2_NB_LINE",nb_line_tJavaRow_2);
				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"Final_data");
			  	}
			  	
 

ok_Hash.put("tJavaRow_2", true);
end_Hash.put("tJavaRow_2", System.currentTimeMillis());




/**
 * [tJavaRow_2 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
			}
			conn_tDBOutput_1.commit();
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
				rowsToCommitCount_tDBOutput_1 = 0;
			}
			commitCounter_tDBOutput_1 = 0;
		
    	conn_tDBOutput_1 .close();
    	
    	resourceMap.put("finish_tDBOutput_1", true);
    	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row4");
			  	}
			  	
 

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */

	
	/**
	 * [tLogRow_2 end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_2 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_2 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_2 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_2);
                    }
                    
                    consoleOut_tLogRow_2.println(util_tLogRow_2.format().toString());
                    consoleOut_tLogRow_2.flush();
//////
globalMap.put("tLogRow_2_NB_LINE",nb_line_tLogRow_2);

///////////////////////    			

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row6");
			  	}
			  	
 

ok_Hash.put("tLogRow_2", true);
end_Hash.put("tLogRow_2", System.currentTimeMillis());




/**
 * [tLogRow_2 end ] stop
 */












				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row2"); 
				     			
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row3"); 
				     			
				try{
					
	
	/**
	 * [tFileInputDelimited_2 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";
	
	

 



/**
 * [tFileInputDelimited_2 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";
	
	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tLogRow_1 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_1";
	
	

 



/**
 * [tLogRow_1 finally ] stop
 */




	
	/**
	 * [tJavaRow_2 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";
	
	

 



/**
 * [tJavaRow_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_1") == null){
            java.sql.Connection ctn_tDBOutput_1 = null;
            if((ctn_tDBOutput_1 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_1")) != null){
                try {
                    ctn_tDBOutput_1.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_1) {
                    String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :" + sqlEx_tDBOutput_1.getMessage();
                    System.err.println(errorMessage_tDBOutput_1);
                }
            }
        }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */

	
	/**
	 * [tLogRow_2 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_2";
	
	

 



/**
 * [tLogRow_2 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableComparableLookupRow<row2Struct> {
    final static byte[] commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];
    static byte[] commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String brand;

				public String getBrand () {
					return this.brand;
				}

				public Boolean brandIsNullable(){
				    return true;
				}
				public Boolean brandIsKey(){
				    return false;
				}
				public Integer brandLength(){
				    return 50;
				}
				public Integer brandPrecision(){
				    return 0;
				}
				public String brandDefault(){
				
					return null;
				
				}
				public String brandComment(){
				
				    return "";
				
				}
				public String brandPattern(){
				
					return "";
				
				}
				public String brandOriginalDbColumnName(){
				
					return "brand";
				
				}

				
			    public String model;

				public String getModel () {
					return this.model;
				}

				public Boolean modelIsNullable(){
				    return true;
				}
				public Boolean modelIsKey(){
				    return false;
				}
				public Integer modelLength(){
				    return 50;
				}
				public Integer modelPrecision(){
				    return 0;
				}
				public String modelDefault(){
				
					return null;
				
				}
				public String modelComment(){
				
				    return "";
				
				}
				public String modelPattern(){
				
					return "";
				
				}
				public String modelOriginalDbColumnName(){
				
					return "model";
				
				}

				
			    public String vendeur;

				public String getVendeur () {
					return this.vendeur;
				}

				public Boolean vendeurIsNullable(){
				    return true;
				}
				public Boolean vendeurIsKey(){
				    return false;
				}
				public Integer vendeurLength(){
				    return 50;
				}
				public Integer vendeurPrecision(){
				    return 0;
				}
				public String vendeurDefault(){
				
					return null;
				
				}
				public String vendeurComment(){
				
				    return "";
				
				}
				public String vendeurPattern(){
				
					return "";
				
				}
				public String vendeurOriginalDbColumnName(){
				
					return "vendeur";
				
				}

				
			    public Float prix_magasin;

				public Float getPrix_magasin () {
					return this.prix_magasin;
				}

				public Boolean prix_magasinIsNullable(){
				    return true;
				}
				public Boolean prix_magasinIsKey(){
				    return false;
				}
				public Integer prix_magasinLength(){
				    return 12;
				}
				public Integer prix_magasinPrecision(){
				    return 0;
				}
				public String prix_magasinDefault(){
				
					return "";
				
				}
				public String prix_magasinComment(){
				
				    return "";
				
				}
				public String prix_magasinPattern(){
				
					return "";
				
				}
				public String prix_magasinOriginalDbColumnName(){
				
					return "prix_magasin";
				
				}

				
			    public Integer stock;

				public Integer getStock () {
					return this.stock;
				}

				public Boolean stockIsNullable(){
				    return true;
				}
				public Boolean stockIsKey(){
				    return false;
				}
				public Integer stockLength(){
				    return 10;
				}
				public Integer stockPrecision(){
				    return 0;
				}
				public String stockDefault(){
				
					return "";
				
				}
				public String stockComment(){
				
				    return "";
				
				}
				public String stockPattern(){
				
					return "";
				
				}
				public String stockOriginalDbColumnName(){
				
					return "stock";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.brand == null) ? 0 : this.brand.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row2Struct other = (row2Struct) obj;
		
						if (this.brand == null) {
							if (other.brand != null)
								return false;
						
						} else if (!this.brand.equals(other.brand))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row2Struct other) {

		other.brand = this.brand;
	            other.model = this.model;
	            other.vendeur = this.vendeur;
	            other.prix_magasin = this.prix_magasin;
	            other.stock = this.stock;
	            
	}

	public void copyKeysDataTo(row2Struct other) {

		other.brand = this.brand;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}
	private Integer readInteger(DataInputStream dis, ObjectInputStream ois) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
			intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		Integer intReturn;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
			intReturn = unmarshaller.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, DataOutputStream dos,org.jboss.marshalling.Marshaller marshaller ) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.brand = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.brand = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.brand,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.brand,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
						this.model = readString(dis,ois);
					
						this.vendeur = readString(dis,ois);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.prix_magasin = null;
           				} else {
           			    	this.prix_magasin = dis.readFloat();
           				}
					
						this.stock = readInteger(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
						this.model = readString(dis,objectIn);
					
						this.vendeur = readString(dis,objectIn);
					
			            length = objectIn.readByte();
           				if (length == -1) {
           	    			this.prix_magasin = null;
           				} else {
           			    	this.prix_magasin = objectIn.readFloat();
           				}
					
						this.stock = readInteger(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
						writeString(this.model, dos, oos);
					
						writeString(this.vendeur, dos, oos);
					
						if(this.prix_magasin == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.prix_magasin);
		            	}
					
					writeInteger(this.stock, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
						writeString(this.model, dos, objectOut);
					
						writeString(this.vendeur, dos, objectOut);
					
						if(this.prix_magasin == null) {
							objectOut.writeByte(-1);
						} else {
							objectOut.writeByte(0);
							objectOut.writeFloat(this.prix_magasin);
		            	}
					
					writeInteger(this.stock, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("brand="+brand);
		sb.append(",model="+model);
		sb.append(",vendeur="+vendeur);
		sb.append(",prix_magasin="+String.valueOf(prix_magasin));
		sb.append(",stock="+String.valueOf(stock));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.brand, other.brand);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tAdvancedHash_row2 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row2", false);
		start_Hash.put("tAdvancedHash_row2", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row2";
	
	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row2");
					}
				
		int tos_count_tAdvancedHash_row2 = 0;
		

			   		// connection name:row2
			   		// source node:tDBInput_1 - inputs:(after_tFileInputDelimited_2) outputs:(row2,row2) | target node:tAdvancedHash_row2 - inputs:(row2) outputs:()
			   		// linked node: tMap_1 - inputs:(row1,row2,row3) outputs:(csv_mysql,Final_data)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row2 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct> tHash_Lookup_row2 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row2Struct>getLookup(matchingModeEnum_row2);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row2", tHash_Lookup_row2);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row2 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";
	
	
		int tos_count_tDBInput_1 = 0;
		
	
	
		    java.util.Calendar calendar_tDBInput_1 = java.util.Calendar.getInstance();
		    calendar_tDBInput_1.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_1 = calendar_tDBInput_1.getTime();
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "com.mysql.cj.jdbc.Driver";
			    java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = "root";
				
				 
	final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:ssN2xnQ2VGry/Tqlp0U+f9SNT3F5RZ+Rwa7qSA==");
				
				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;
				
        String properties_tDBInput_1 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
        if (properties_tDBInput_1 == null || properties_tDBInput_1.trim().length() == 0) {
            properties_tDBInput_1 = "";
        }
        String url_tDBInput_1 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "phones" + "?" + properties_tDBInput_1;
				
				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1,dbUser_tDBInput_1,dbPwd_tDBInput_1);
		        
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT \n  `smartphone_prices`.`brand`, \n  `smartphone_prices`.`model`, \n  `smartphone_prices`.`vendeur`, \n  `smartphone"
+"_prices`.`prix_magasin`, \n  `smartphone_prices`.`stock`\nFROM `smartphone_prices`";
		    

		    globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);

		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row2.brand = null;
							} else {
	                         		
        	row2.brand = routines.system.JDBCUtil.getString(rs_tDBInput_1, 1, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row2.model = null;
							} else {
	                         		
        	row2.model = routines.system.JDBCUtil.getString(rs_tDBInput_1, 2, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row2.vendeur = null;
							} else {
	                         		
        	row2.vendeur = routines.system.JDBCUtil.getString(rs_tDBInput_1, 3, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row2.prix_magasin = null;
							} else {
		                          
            row2.prix_magasin = rs_tDBInput_1.getFloat(4);
            if(rs_tDBInput_1.wasNull()){
                    row2.prix_magasin = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row2.stock = null;
							} else {
		                          
            row2.stock = rs_tDBInput_1.getInt(5);
            if(rs_tDBInput_1.wasNull()){
                    row2.stock = null;
            }
		                    }
					

 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row2 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row2";
	
	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row2"
						
						);
					}
					


			   
			   

					row2Struct row2_HashRow = new row2Struct();
		   	   	   
				
				row2_HashRow.brand = row2.brand;
				
				row2_HashRow.model = row2.model;
				
				row2_HashRow.vendeur = row2.vendeur;
				
				row2_HashRow.prix_magasin = row2.prix_magasin;
				
				row2_HashRow.stock = row2.stock;
				
			tHash_Lookup_row2.put(row2_HashRow);
			
            




 


	tos_count_tAdvancedHash_row2++;

/**
 * [tAdvancedHash_row2 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row2";
	
	

 



/**
 * [tAdvancedHash_row2 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row2 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row2";
	
	

 



/**
 * [tAdvancedHash_row2 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
		if(conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {
			
			conn_tDBInput_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
		}
		
}
globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);

 

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row2 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row2";
	
	

tHash_Lookup_row2.endPut();

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row2");
			  	}
			  	
 

ok_Hash.put("tAdvancedHash_row2", true);
end_Hash.put("tAdvancedHash_row2", System.currentTimeMillis());




/**
 * [tAdvancedHash_row2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row2 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row2";
	
	

 



/**
 * [tAdvancedHash_row2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableComparableLookupRow<row3Struct> {
    final static byte[] commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];
    static byte[] commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String brand;

				public String getBrand () {
					return this.brand;
				}

				public Boolean brandIsNullable(){
				    return false;
				}
				public Boolean brandIsKey(){
				    return false;
				}
				public Integer brandLength(){
				    return 50;
				}
				public Integer brandPrecision(){
				    return 0;
				}
				public String brandDefault(){
				
					return null;
				
				}
				public String brandComment(){
				
				    return "";
				
				}
				public String brandPattern(){
				
					return "";
				
				}
				public String brandOriginalDbColumnName(){
				
					return "brand";
				
				}

				
			    public String country;

				public String getCountry () {
					return this.country;
				}

				public Boolean countryIsNullable(){
				    return true;
				}
				public Boolean countryIsKey(){
				    return false;
				}
				public Integer countryLength(){
				    return 50;
				}
				public Integer countryPrecision(){
				    return 0;
				}
				public String countryDefault(){
				
					return null;
				
				}
				public String countryComment(){
				
				    return "";
				
				}
				public String countryPattern(){
				
					return "";
				
				}
				public String countryOriginalDbColumnName(){
				
					return "country";
				
				}

				
			    public String continent;

				public String getContinent () {
					return this.continent;
				}

				public Boolean continentIsNullable(){
				    return true;
				}
				public Boolean continentIsKey(){
				    return false;
				}
				public Integer continentLength(){
				    return 20;
				}
				public Integer continentPrecision(){
				    return 0;
				}
				public String continentDefault(){
				
					return null;
				
				}
				public String continentComment(){
				
				    return "";
				
				}
				public String continentPattern(){
				
					return "";
				
				}
				public String continentOriginalDbColumnName(){
				
					return "continent";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.brand == null) ? 0 : this.brand.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row3Struct other = (row3Struct) obj;
		
						if (this.brand == null) {
							if (other.brand != null)
								return false;
						
						} else if (!this.brand.equals(other.brand))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row3Struct other) {

		other.brand = this.brand;
	            other.country = this.country;
	            other.continent = this.continent;
	            
	}

	public void copyKeysDataTo(row3Struct other) {

		other.brand = this.brand;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	
	private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			unmarshaller.read(byteArray);
			strReturn = new String(byteArray, utf8Charset);
		}
		return strReturn;
	}
	
	private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
	}

	private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
	}

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.brand = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.brand = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.brand,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.brand,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
						this.country = readString(dis,ois);
					
						this.continent = readString(dis,ois);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
						this.country = readString(dis,objectIn);
					
						this.continent = readString(dis,objectIn);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
						writeString(this.country, dos, oos);
					
						writeString(this.continent, dos, oos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
						writeString(this.country, dos, objectOut);
					
						writeString(this.continent, dos, objectOut);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("brand="+brand);
		sb.append(",country="+country);
		sb.append(",continent="+continent);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.brand, other.brand);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tAdvancedHash_row3 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row3", false);
		start_Hash.put("tAdvancedHash_row3", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row3";
	
	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row3");
					}
				
		int tos_count_tAdvancedHash_row3 = 0;
		

			   		// connection name:row3
			   		// source node:tDBInput_2 - inputs:(after_tFileInputDelimited_2) outputs:(row3,row3) | target node:tAdvancedHash_row3 - inputs:(row3) outputs:()
			   		// linked node: tMap_1 - inputs:(row1,row2,row3) outputs:(csv_mysql,Final_data)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row3 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct> tHash_Lookup_row3 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row3Struct>getLookup(matchingModeEnum_row3);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row3", tHash_Lookup_row3);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row3 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_2";
	
	
		int tos_count_tDBInput_2 = 0;
		
	
    
	
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				String driverClass_tDBInput_2 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_2 = java.lang.Class.forName(driverClass_tDBInput_2);
				String dbUser_tDBInput_2 = "postgres";
				
				 
	final String decryptedPassword_tDBInput_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:jejtxpzvLHr5io/JGXlxUzsYUTWtWFlIC/9V8lWS/poP");
				
				String dbPwd_tDBInput_2 = decryptedPassword_tDBInput_2;
				
				String url_tDBInput_2 = "jdbc:postgresql://" + "localhost" + ":" + "5432" + "/" + "Phones";
				
				conn_tDBInput_2 = java.sql.DriverManager.getConnection(url_tDBInput_2,dbUser_tDBInput_2,dbPwd_tDBInput_2);
		        
				conn_tDBInput_2.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

		    String dbquery_tDBInput_2 = "SELECT \n  \"public\".\"brand_origin\".\"brand\", \n  \"public\".\"brand_origin\".\"country\", \n  \"public\".\"brand_orig"
+"in\".\"continent\"\nFROM \"public\".\"brand_origin\"";
		    

		    globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);

		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row3.brand = null;
							} else {
	                         		
        	row3.brand = routines.system.JDBCUtil.getString(rs_tDBInput_2, 1, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row3.country = null;
							} else {
	                         		
        	row3.country = routines.system.JDBCUtil.getString(rs_tDBInput_2, 2, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 3) {
								row3.continent = null;
							} else {
	                         		
        	row3.continent = routines.system.JDBCUtil.getString(rs_tDBInput_2, 3, false);
		                    }
					


 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row3 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";
	
	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row3"
						
						);
					}
					


			   
			   

					row3Struct row3_HashRow = new row3Struct();
		   	   	   
				
				row3_HashRow.brand = row3.brand;
				
				row3_HashRow.country = row3.country;
				
				row3_HashRow.continent = row3.continent;
				
			tHash_Lookup_row3.put(row3_HashRow);
			
            




 


	tos_count_tAdvancedHash_row3++;

/**
 * [tAdvancedHash_row3 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";
	
	

 



/**
 * [tAdvancedHash_row3 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row3 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";
	
	

 



/**
 * [tAdvancedHash_row3 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	

	}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
	if(conn_tDBInput_2 != null && !conn_tDBInput_2.isClosed()) {
		
			conn_tDBInput_2.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
 

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());




/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row3 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";
	
	

tHash_Lookup_row3.endPut();

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row3");
			  	}
			  	
 

ok_Hash.put("tAdvancedHash_row3", true);
end_Hash.put("tAdvancedHash_row3", System.currentTimeMillis());




/**
 * [tAdvancedHash_row3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row3 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row3";
	
	

 



/**
 * [tAdvancedHash_row3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	


public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tJava_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public void tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";
	
	
		int tos_count_tJava_1 = 0;
		


globalMap.put("JOB_START", new java.util.Date());
globalMap.put("ROWS_INSERTED", 0);
globalMap.put("ROWS_REJECTED", 0);
globalMap.put("JOB_NAME", "ETL_Phones_informations");
globalMap.put("JOB_STATUS", "STARTED");

System.out.println(">>> Job démarré à " + globalMap.get("JOB_START"));

 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 process_data_begin ] stop
 */
	
	/**
	 * [tJava_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 process_data_end ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());




/**
 * [tJava_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";
	
	

 



/**
 * [tJava_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}
	


public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tJava_2Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	


public void tJava_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_2", false);
		start_Hash.put("tJava_2", System.currentTimeMillis());
		
	
	currentComponent="tJava_2";
	
	
		int tos_count_tJava_2 = 0;
		


globalMap.put("JOB_END", new java.util.Date());
globalMap.put("JOB_STATUS", "SUCCESS");

// Calcul durée
long start = ((java.util.Date) globalMap.get("JOB_START")).getTime();
long end = ((java.util.Date) globalMap.get("JOB_END")).getTime();
long duration_ms = end - start;
globalMap.put("JOB_DURATION_MS", duration_ms);

System.out.println(">>> Job terminé");
System.out.println("Durée (ms) : " + duration_ms);
System.out.println("Lignes insérées : " + globalMap.get("ROWS_INSERTED"));

 



/**
 * [tJava_2 begin ] stop
 */
	
	/**
	 * [tJava_2 main ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 


	tos_count_tJava_2++;

/**
 * [tJava_2 main ] stop
 */
	
	/**
	 * [tJava_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 process_data_begin ] stop
 */
	
	/**
	 * [tJava_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 process_data_end ] stop
 */
	
	/**
	 * [tJava_2 end ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 

ok_Hash.put("tJava_2", true);
end_Hash.put("tJava_2", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tFixedFlowInput_1Process(globalMap);



/**
 * [tJava_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_2 finally ] start
	 */

	

	
	
	currentComponent="tJava_2";
	
	

 



/**
 * [tJava_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}
	


public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];
    static byte[] commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[0];

	
			    public String job_name;

				public String getJob_name () {
					return this.job_name;
				}

				public Boolean job_nameIsNullable(){
				    return true;
				}
				public Boolean job_nameIsKey(){
				    return false;
				}
				public Integer job_nameLength(){
				    return null;
				}
				public Integer job_namePrecision(){
				    return null;
				}
				public String job_nameDefault(){
				
					return null;
				
				}
				public String job_nameComment(){
				
				    return "";
				
				}
				public String job_namePattern(){
				
					return "";
				
				}
				public String job_nameOriginalDbColumnName(){
				
					return "job_name";
				
				}

				
			    public java.util.Date job_start;

				public java.util.Date getJob_start () {
					return this.job_start;
				}

				public Boolean job_startIsNullable(){
				    return true;
				}
				public Boolean job_startIsKey(){
				    return false;
				}
				public Integer job_startLength(){
				    return null;
				}
				public Integer job_startPrecision(){
				    return null;
				}
				public String job_startDefault(){
				
					return null;
				
				}
				public String job_startComment(){
				
				    return "";
				
				}
				public String job_startPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String job_startOriginalDbColumnName(){
				
					return "job_start";
				
				}

				
			    public java.util.Date job_end;

				public java.util.Date getJob_end () {
					return this.job_end;
				}

				public Boolean job_endIsNullable(){
				    return true;
				}
				public Boolean job_endIsKey(){
				    return false;
				}
				public Integer job_endLength(){
				    return null;
				}
				public Integer job_endPrecision(){
				    return null;
				}
				public String job_endDefault(){
				
					return null;
				
				}
				public String job_endComment(){
				
				    return "";
				
				}
				public String job_endPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String job_endOriginalDbColumnName(){
				
					return "job_end";
				
				}

				
			    public Long duration_ms;

				public Long getDuration_ms () {
					return this.duration_ms;
				}

				public Boolean duration_msIsNullable(){
				    return true;
				}
				public Boolean duration_msIsKey(){
				    return false;
				}
				public Integer duration_msLength(){
				    return null;
				}
				public Integer duration_msPrecision(){
				    return null;
				}
				public String duration_msDefault(){
				
					return null;
				
				}
				public String duration_msComment(){
				
				    return "";
				
				}
				public String duration_msPattern(){
				
					return "";
				
				}
				public String duration_msOriginalDbColumnName(){
				
					return "duration_ms";
				
				}

				
			    public Integer rows_inserted;

				public Integer getRows_inserted () {
					return this.rows_inserted;
				}

				public Boolean rows_insertedIsNullable(){
				    return true;
				}
				public Boolean rows_insertedIsKey(){
				    return false;
				}
				public Integer rows_insertedLength(){
				    return null;
				}
				public Integer rows_insertedPrecision(){
				    return null;
				}
				public String rows_insertedDefault(){
				
					return null;
				
				}
				public String rows_insertedComment(){
				
				    return "";
				
				}
				public String rows_insertedPattern(){
				
					return "";
				
				}
				public String rows_insertedOriginalDbColumnName(){
				
					return "rows_inserted";
				
				}

				
			    public Integer rows_rejected;

				public Integer getRows_rejected () {
					return this.rows_rejected;
				}

				public Boolean rows_rejectedIsNullable(){
				    return true;
				}
				public Boolean rows_rejectedIsKey(){
				    return false;
				}
				public Integer rows_rejectedLength(){
				    return null;
				}
				public Integer rows_rejectedPrecision(){
				    return null;
				}
				public String rows_rejectedDefault(){
				
					return null;
				
				}
				public String rows_rejectedComment(){
				
				    return "";
				
				}
				public String rows_rejectedPattern(){
				
					return "";
				
				}
				public String rows_rejectedOriginalDbColumnName(){
				
					return "rows_rejected";
				
				}

				
			    public String job_status;

				public String getJob_status () {
					return this.job_status;
				}

				public Boolean job_statusIsNullable(){
				    return true;
				}
				public Boolean job_statusIsKey(){
				    return false;
				}
				public Integer job_statusLength(){
				    return null;
				}
				public Integer job_statusPrecision(){
				    return null;
				}
				public String job_statusDefault(){
				
					return null;
				
				}
				public String job_statusComment(){
				
				    return "";
				
				}
				public String job_statusPattern(){
				
					return "";
				
				}
				public String job_statusOriginalDbColumnName(){
				
					return "job_status";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length) {
				if(length < 1024 && commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations.length == 0) {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[1024];
				} else {
   					commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length);
			strReturn = new String(commonByteArray_ETL_PHONES_THEME11_ETL_Phones_informations, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.job_name = readString(dis);
					
					this.job_start = readDate(dis);
					
					this.job_end = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration_ms = null;
           				} else {
           			    	this.duration_ms = dis.readLong();
           				}
					
						this.rows_inserted = readInteger(dis);
					
						this.rows_rejected = readInteger(dis);
					
					this.job_status = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_ETL_PHONES_THEME11_ETL_Phones_informations) {

        	try {

        		int length = 0;
		
					this.job_name = readString(dis);
					
					this.job_start = readDate(dis);
					
					this.job_end = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration_ms = null;
           				} else {
           			    	this.duration_ms = dis.readLong();
           				}
					
						this.rows_inserted = readInteger(dis);
					
						this.rows_rejected = readInteger(dis);
					
					this.job_status = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.job_name,dos);
					
					// java.util.Date
				
						writeDate(this.job_start,dos);
					
					// java.util.Date
				
						writeDate(this.job_end,dos);
					
					// Long
				
						if(this.duration_ms == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration_ms);
		            	}
					
					// Integer
				
						writeInteger(this.rows_inserted,dos);
					
					// Integer
				
						writeInteger(this.rows_rejected,dos);
					
					// String
				
						writeString(this.job_status,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.job_name,dos);
					
					// java.util.Date
				
						writeDate(this.job_start,dos);
					
					// java.util.Date
				
						writeDate(this.job_end,dos);
					
					// Long
				
						if(this.duration_ms == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration_ms);
		            	}
					
					// Integer
				
						writeInteger(this.rows_inserted,dos);
					
					// Integer
				
						writeInteger(this.rows_rejected,dos);
					
					// String
				
						writeString(this.job_status,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("job_name="+job_name);
		sb.append(",job_start="+String.valueOf(job_start));
		sb.append(",job_end="+String.valueOf(job_end));
		sb.append(",duration_ms="+String.valueOf(duration_ms));
		sb.append(",rows_inserted="+String.valueOf(rows_inserted));
		sb.append(",rows_rejected="+String.valueOf(rows_rejected));
		sb.append(",job_status="+job_status);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tFixedFlowInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();




	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";
	
	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row5");
					}
				
		int tos_count_tDBOutput_2 = 0;
		





String dbschema_tDBOutput_2 = null;
	dbschema_tDBOutput_2 = "public";
	

String tableName_tDBOutput_2 = null;
if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
	tableName_tDBOutput_2 = ("etl_metrics");
} else {
	tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("etl_metrics");
}


int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

boolean whetherReject_tDBOutput_2 = false;

java.sql.Connection conn_tDBOutput_2 = null;
String dbUser_tDBOutput_2 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_2 = "jdbc:postgresql://"+"localhost"+":"+"5432"+"/"+"Phones_cible";
    dbUser_tDBOutput_2 = "postgres";
 
	final String decryptedPassword_tDBOutput_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:pQ1uYmlioSRv4fTRbhfMvY4BQBXBs0dWfP4Jzuru0iJ9");

    String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;

    conn_tDBOutput_2 = java.sql.DriverManager.getConnection(url_tDBOutput_2,dbUser_tDBOutput_2,dbPwd_tDBOutput_2);
	
	resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);
        conn_tDBOutput_2.setAutoCommit(false);
        int commitEvery_tDBOutput_2 = 10000;
        int commitCounter_tDBOutput_2 = 0;


   int batchSize_tDBOutput_2 = 10000;
   int batchSizeCounter_tDBOutput_2=0;

int count_tDBOutput_2=0;
        java.lang.StringBuilder sb_tDBOutput_2 = new java.lang.StringBuilder();
        sb_tDBOutput_2.append("INSERT INTO \"").append(tableName_tDBOutput_2).append("\" (\"job_name\",\"job_start\",\"job_end\",\"duration_ms\",\"rows_inserted\",\"rows_rejected\",\"job_status\") VALUES (?,?,?,?,?,?,?)");

        String insert_tDBOutput_2 = sb_tDBOutput_2.toString();
        
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_1", false);
		start_Hash.put("tFixedFlowInput_1", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_1";
	
	
		int tos_count_tFixedFlowInput_1 = 0;
		

	    for (int i_tFixedFlowInput_1 = 0 ; i_tFixedFlowInput_1 < 1 ; i_tFixedFlowInput_1++) {
	                	            	
    	            		row5.job_name = "ETL_Phones_informations";
    	            	        	            	
    	            		row5.job_start = (java.util.Date)globalMap.get("JOB_START");
    	            	        	            	
    	            		row5.job_end = (java.util.Date)globalMap.get("JOB_END");
    	            	        	            	
    	            		row5.duration_ms = ((Long)globalMap.get("JOB_DURATION_MS"));
    	            	        	            	
    	            		row5.rows_inserted = (Integer)globalMap.get("ROWS_INSERTED");
    	            	        	            	
    	            		row5.rows_rejected = (Integer)globalMap.get("ROWS_REJECTED");
    	            	        	            	
    	            		row5.job_status = (String)globalMap.get("JOB_STATUS");
    	            	

 



/**
 * [tFixedFlowInput_1 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_1 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";
	
	

 


	tos_count_tFixedFlowInput_1++;

/**
 * [tFixedFlowInput_1 main ] stop
 */
	
	/**
	 * [tFixedFlowInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";
	
	

 



/**
 * [tFixedFlowInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row5"
						
						);
					}
					



        whetherReject_tDBOutput_2 = false;
                    if(row5.job_name == null) {
pstmt_tDBOutput_2.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(1, row5.job_name);
}

                    if(row5.job_start != null) {
pstmt_tDBOutput_2.setTimestamp(2, new java.sql.Timestamp(row5.job_start.getTime()));
} else {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.TIMESTAMP);
}

                    if(row5.job_end != null) {
pstmt_tDBOutput_2.setTimestamp(3, new java.sql.Timestamp(row5.job_end.getTime()));
} else {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.TIMESTAMP);
}

                    if(row5.duration_ms == null) {
pstmt_tDBOutput_2.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setLong(4, row5.duration_ms);
}

                    if(row5.rows_inserted == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(5, row5.rows_inserted);
}

                    if(row5.rows_rejected == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(6, row5.rows_rejected);
}

                    if(row5.job_status == null) {
pstmt_tDBOutput_2.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(7, row5.job_status);
}

			
    		pstmt_tDBOutput_2.addBatch();
    		nb_line_tDBOutput_2++;
    		  
    		  
    		  batchSizeCounter_tDBOutput_2++;
    		  
    			if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                try {
						int countSum_tDBOutput_2 = 0;
						    
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
				    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            	    	batchSizeCounter_tDBOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
				    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
				    	String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						}else{
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}
				    	
				    	int countSum_tDBOutput_2 = 0;
						for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    	System.err.println(errormessage_tDBOutput_2);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_2++;
                if(commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {
                if ((batchSize_tDBOutput_2 > 0) && (batchSizeCounter_tDBOutput_2 > 0)) {
                try {
                		int countSum_tDBOutput_2 = 0;
                		    
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
            	    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
            	    	
            	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
            	    	
                batchSizeCounter_tDBOutput_2 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
			    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
			    	String errormessage_tDBOutput_2;
					if (ne_tDBOutput_2 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
						errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
					}else{
						errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
					}
			    	
			    	int countSum_tDBOutput_2 = 0;
					for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
					
			    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
			    	
			    	System.err.println(errormessage_tDBOutput_2);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_2 != 0){
                    	
                    }
                    conn_tDBOutput_2.commit();
                    if(rowsToCommitCount_tDBOutput_2 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_2 = 0;
                    }
                    commitCounter_tDBOutput_2=0;
                }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */



	
	/**
	 * [tFixedFlowInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";
	
	

 



/**
 * [tFixedFlowInput_1 process_data_end ] stop
 */
	
	/**
	 * [tFixedFlowInput_1 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";
	
	

        }
        globalMap.put("tFixedFlowInput_1_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_1", true);
end_Hash.put("tFixedFlowInput_1", System.currentTimeMillis());




/**
 * [tFixedFlowInput_1 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	



	    try {
				int countSum_tDBOutput_2 = 0;
				if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {
						
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				}
		    	
		    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
	    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
	    	String errormessage_tDBOutput_2;
			if (ne_tDBOutput_2 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
				errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
			}else{
				errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
			}
	    	
	    	int countSum_tDBOutput_2 = 0;
			for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
				countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
			}
			rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
			
	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
	    	
	    	System.err.println(errormessage_tDBOutput_2);
	    	
		}
	    
        if(pstmt_tDBOutput_2 != null) {
        		
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);
			if(rowsToCommitCount_tDBOutput_2 != 0){
				
			}
			conn_tDBOutput_2.commit();
			if(rowsToCommitCount_tDBOutput_2 != 0){
				
				rowsToCommitCount_tDBOutput_2 = 0;
			}
			commitCounter_tDBOutput_2 = 0;
		
    	conn_tDBOutput_2 .close();
    	
    	resourceMap.put("finish_tDBOutput_2", true);
    	

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row5");
			  	}
			  	
 

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_1 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";
	
	

 



/**
 * [tFixedFlowInput_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_2") == null){
            java.sql.Connection ctn_tDBOutput_2 = null;
            if((ctn_tDBOutput_2 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_2")) != null){
                try {
                    ctn_tDBOutput_2.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_2) {
                    String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :" + sqlEx_tDBOutput_2.getMessage();
                    System.err.println(errorMessage_tDBOutput_2);
                }
            }
        }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_1_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final ETL_Phones_informations ETL_Phones_informationsClass = new ETL_Phones_informations();

        int exitCode = ETL_Phones_informationsClass.runJobInTOS(args);

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                
            }
        }
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));


		
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }


        if (rootPid==null) {
            rootPid = pid;
        }


        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = ETL_Phones_informations.class.getClassLoader().getResourceAsStream("etl_phones_theme11/etl_phones_informations_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = ETL_Phones_informations.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }
            
            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));


if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}




this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tFileInputDelimited_2Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tFileInputDelimited_2) {
globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", -1);

e_tFileInputDelimited_2.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : ETL_Phones_informations");
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }














    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--context_file")) {
        	String keyValue = arg.substring(15);
        	String filePath = new String(java.util.Base64.getDecoder().decode(keyValue));
        	java.nio.file.Path contextFile = java.nio.file.Paths.get(filePath);
            try (java.io.BufferedReader reader = java.nio.file.Files.newBufferedReader(contextFile)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    int index = -1;
                    if ( (index = line.indexOf('=')) > -1) {
							if (line.startsWith("--context_param")) {
								if ("id_Password".equals(context_param.getContextType(line.substring(16, index)))) {
									context_param.put(line.substring(16, index), routines.system.PasswordEncryptUtil.decryptPassword(
											line.substring(index + 1)));
								} else {
									context_param.put(line.substring(16, index), line.substring(index + 1));
								}
							}else {//--context_type
								context_param.setContextType(line.substring(15, index), line.substring(index + 1));
							}
                    }
                }
            } catch (java.io.IOException e) {
            	System.err.println("Could not load the context file: " + filePath);
                e.printStackTrace();
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     312242 characters generated by Talend Open Studio for Data Integration 
 *     on the 3 décembre 2025 à 16:53:19 GMT
 ************************************************************************************************/